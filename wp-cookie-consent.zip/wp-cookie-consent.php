<?php
/**
 * Plugin Name: WP Cookie Consent
 * Plugin URI: https://github.com/hyveli/wp-cookie-consent
 * Description: GDPR-compliant cookie consent management with Google Analytics 4 (GA4) support and Consent Mode v2 integration.
 * Version: 1.0.4
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Hyveli, LLC
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-cookie-consent
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPCC_VERSION', '1.0.4');
define('WPCC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPCC_PLUGIN_URL', plugin_dir_url(__FILE__));

// ============================================
// GEOLOCATION HELPERS
// ============================================

/**
 * Get visitor's country code from Cloudflare header
 * @return string|null Two-letter country code or null if not available
 */
function wpcc_get_country_code() {
    return $_SERVER['HTTP_CF_IPCOUNTRY'] ?? null;
}

/**
 * Check if a country code is in GDPR jurisdiction
 * @param string|null $code Two-letter country code
 * @return bool True if GDPR applies
 */
function wpcc_is_gdpr_country($code) {
    if (!$code) {
        return false;
    }

    $gdpr = [
        'AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR',
        'DE','GR','HU','IE','IT','LV','LT','LU','MT','NL',
        'PL','PT','RO','SK','SI','ES','SE', // EU 27
        'GB', // UK (retained GDPR post-Brexit)
        'NO','IS','LI' // EEA non-EU
    ];

    return in_array(strtoupper($code), $gdpr);
}

/**
 * Determine which consent UI to show based on geolocation
 * @return string 'banner' for GDPR banner, 'footer' for US footer strip, 'banner' as default
 */
function wpcc_get_consent_mode() {
    $country = wpcc_get_country_code();

    // If no geolocation available, show banner for safety
    if (!$country) {
        return get_option('wpcc_fallback_mode', 'banner');
    }

    // GDPR countries get the full banner
    if (wpcc_is_gdpr_country($country)) {
        return 'banner';
    }

    // USA gets footer strip (CCPA compliance)
    if (strtoupper($country) === 'US') {
        return get_option('wpcc_usa_mode', 'footer');
    }

    // All other countries default to banner
    return 'banner';
}

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    // Prevent loading the autoloader multiple times
    if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        require_once __DIR__ . '/vendor/autoload.php';
    }

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-cookie-consent-dist/main/release.json',
            __FILE__,
            'wp-cookie-consent'
        );

        // Force update check if URL parameter is present
        if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
            delete_site_transient('update_plugins');
            $updateChecker->checkForUpdates();
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>✅ Update check cache cleared! WordPress will check for updates now.</p></div>';
            });
        }
    }
}

// Activation hook
register_activation_hook(__FILE__, 'wpcc_activate');
function wpcc_activate() {
    wpcc_create_default_options();
    flush_rewrite_rules();
}

// Check for version changes and upgrade
add_action('plugins_loaded', 'wpcc_check_version');
function wpcc_check_version() {
    $installed_version = get_option('wpcc_version', '0.0.0');

    if (version_compare($installed_version, WPCC_VERSION, '<')) {
        // Version changed - run upgrade
        wpcc_upgrade($installed_version);
        update_option('wpcc_version', WPCC_VERSION);
    }
}

// Upgrade routine
function wpcc_upgrade($from_version) {
    // Create any missing options (for upgrades from older versions)
    wpcc_create_default_options();
}

// Create default options (used by both activation and upgrade)
function wpcc_create_default_options() {
    // Core settings
    add_option('wpcc_enabled', true);
    add_option('wpcc_ga4_id', '');
    add_option('wpcc_banner_title', 'We use cookies');
    add_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.');
    add_option('wpcc_accept_label', 'Accept');
    add_option('wpcc_reject_label', 'Reject');
    add_option('wpcc_consent_expiry_days', 180);

    // Color options (banner)
    add_option('wpcc_banner_bg_color', '#ffffff');
    add_option('wpcc_banner_text_color', '#111111');
    add_option('wpcc_accept_bg_color', '#111111');
    add_option('wpcc_accept_text_color', '#ffffff');
    add_option('wpcc_reject_border_color', '#111111');

    // Learn more link
    add_option('wpcc_learn_more_url', '/privacy-policy#cookies');

    // Geolocation options (v1.1.0+)
    add_option('wpcc_usa_mode', 'footer');
    add_option('wpcc_fallback_mode', 'banner');

    // Footer strip options (v1.1.0+)
    add_option('wpcc_footer_style', 'a');
    add_option('wpcc_footer_copyright', '© ' . date('Y') . ' ' . get_bloginfo('name'));
    add_option('wpcc_footer_show_terms', true);
    add_option('wpcc_footer_terms_url', '/terms-of-service');
    add_option('wpcc_footer_show_privacy', true);
    add_option('wpcc_footer_privacy_url', '/privacy-policy');
    add_option('wpcc_footer_show_cookies', true);
    add_option('wpcc_footer_cookies_url', '/cookie-policy');
    add_option('wpcc_footer_bg_color', '#0d0b08');
    add_option('wpcc_footer_text_color', 'rgba(255,255,255,0.38)');

    // Store current version
    add_option('wpcc_version', WPCC_VERSION);
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpcc_deactivate');
function wpcc_deactivate() {
    flush_rewrite_rules();
}

// ============================================
// COOKIE CONSENT FEATURES
// ============================================

// Output banner styles in head
add_action('wp_head', 'wpcc_output_styles', 100);
function wpcc_output_styles() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }
    echo '<style id="wpcc-banner-styles">' . wpcc_get_banner_styles() . '</style>';
}

// Output consent script in footer
add_action('wp_footer', 'wpcc_output_script', 20);
function wpcc_output_script() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }
    echo '<script id="wpcc-consent-script">' . wpcc_get_consent_script() . '</script>';
}

// Add Consent Mode v2 script to <head> (must be first)
add_action('wp_head', 'wpcc_render_consent_mode', 1);
function wpcc_render_consent_mode() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }

    $ga4_id = get_option('wpcc_ga4_id', '');
    if (empty($ga4_id)) {
        return;
    }
    ?>
    <!-- Google Consent Mode v2 -->
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('consent', 'default', {
        'analytics_storage': 'denied',
        'ad_storage': 'denied',
        'functionality_storage': 'denied',
        'personalization_storage': 'denied',
        'wait_for_update': 500
    });
    gtag('js', new Date());
    </script>
    <?php
}

// Render consent UI (banner or footer strip based on geolocation)
add_action('wp_footer', 'wpcc_render_consent_ui', 5);
function wpcc_render_consent_ui() {
    if (!get_option('wpcc_enabled', true)) {
        echo '<!-- WPCC: Plugin disabled -->';
        return;
    }

    $mode = wpcc_get_consent_mode();
    echo '<!-- WPCC: Consent mode is: ' . esc_html($mode) . ' -->';

    if ($mode === 'footer') {
        echo '<!-- WPCC: Calling wpcc_render_footer_strip() -->';
        wpcc_render_footer_strip();
        echo '<!-- WPCC: Footer strip render completed -->';
    } else {
        echo '<!-- WPCC: Calling wpcc_render_gdpr_banner() -->';
        wpcc_render_gdpr_banner();
    }

    // Always output config for JavaScript
    $ga4_id = get_option('wpcc_ga4_id', '');
    $expiry_days = get_option('wpcc_consent_expiry_days', 180);
    ?>
    <script>
    // Pass PHP variables to JavaScript
    window.wpccConfig = {
        ga4Id: '<?php echo esc_js($ga4_id); ?>',
        expiryDays: <?php echo absint($expiry_days); ?>,
        mode: '<?php echo esc_js($mode); ?>'
    };
    </script>
    <?php
}

// Render GDPR pill banner (for EU/GDPR countries)
function wpcc_render_gdpr_banner() {
    $title = get_option('wpcc_banner_title', 'We use cookies');
    $body = get_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.');
    $accept_label = get_option('wpcc_accept_label', 'Accept');
    $reject_label = get_option('wpcc_reject_label', 'Reject');
    $learn_more_url = get_option('wpcc_learn_more_url', '/privacy-policy#cookies');
    ?>
    <div id="wpcc-banner" class="wpcc-banner" role="dialog" aria-modal="false" aria-live="polite" aria-label="Cookie consent" style="display:none;">
        <span class="wpcc-banner__text">
            <?php echo wp_kses_post($body); ?> <a href="<?php echo esc_url($learn_more_url); ?>" class="wpcc-banner__link">Learn more</a>
        </span>
        <div class="wpcc-banner__actions">
            <button id="wpcc-reject" class="wpcc-btn wpcc-btn--secondary" type="button" aria-label="<?php echo esc_attr($reject_label); ?>">
                <?php echo esc_html($reject_label); ?>
            </button>
            <button id="wpcc-accept" class="wpcc-btn wpcc-btn--primary" type="button" aria-label="<?php echo esc_attr($accept_label); ?>">
                <?php echo esc_html($accept_label); ?>
            </button>
        </div>
    </div>
    <?php
}

// Render footer strip (for USA/CCPA compliance)
function wpcc_render_footer_strip() {
    // Debug: Log that this function is being called
    error_log('[WPCC] wpcc_render_footer_strip() called');

    $style = get_option('wpcc_footer_style', 'a');
    if (empty($style)) {
        $style = 'a'; // Default to 'a' if empty
    }
    error_log('[WPCC] Footer style value: ' . var_export($style, true));
    $copyright = get_option('wpcc_footer_copyright', '© ' . date('Y') . ' ' . get_bloginfo('name'));
    $show_terms = get_option('wpcc_footer_show_terms', true);
    $terms_url = get_option('wpcc_footer_terms_url', '/terms-of-service');
    $show_privacy = get_option('wpcc_footer_show_privacy', true);
    $privacy_url = get_option('wpcc_footer_privacy_url', '/privacy-policy');
    $show_cookies = get_option('wpcc_footer_show_cookies', true);
    $cookies_url = get_option('wpcc_footer_cookies_url', '/cookie-policy');

    // Official CCPA opt-out icon SVG
    $ccpa_icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 14" role="img" aria-label="Your Privacy Choices opt-out icon"><style>.i0{fill-rule:evenodd;clip-rule:evenodd;fill:#FFFFFF}.i1{fill-rule:evenodd;clip-rule:evenodd;fill:#0066FF}.i2{fill:#FFFFFF}.i3{fill:#0066FF}</style><path class="i0" d="M7.4,12.8h6.8l3.1-11.6H7.4C4.2,1.2,1.6,3.8,1.6,7S4.2,12.8,7.4,12.8z"/><path class="i1" d="M22.6,0H7.4c-3.9,0-7,3.1-7,7s3.1,7,7,7h15.2c3.9,0,7-3.1,7-7S26.4,0,22.6,0zM1.6,7c0-3.2,2.6-5.8,5.8-5.8h9.9l-3.1,11.6H7.4C4.2,12.8,1.6,10.2,1.6,7z"/><path class="i2" d="M24.6,4c0.2,0.2,0.2,0.6,0,0.8L22.5,7l2.2,2.2c0.2,0.2,0.2,0.6,0,0.8c-0.2,0.2-0.6,0.2-0.8,0l-2.2-2.2L19.5,10c-0.2,0.2-0.6,0.2-0.8,0c-0.2-0.2-0.2-0.6,0-0.8L20.8,7l-2.2-2.2c-0.2-0.2-0.2-0.6,0-0.8c0.2-0.2,0.6-0.2,0.8,0l2.2,2.2L23.8,4C24,3.8,24.4,3.8,24.6,4z"/><path class="i3" d="M12.7,4.1c0.2,0.2,0.3,0.6,0.1,0.8L8.6,9.8C8.5,9.9,8.4,10,8.3,10c-0.2,0.1-0.5,0.1-0.7-0.1L5.4,7.7c-0.2-0.2-0.2-0.6,0-0.8c0.2-0.2,0.6-0.2,0.8,0L8,8.6l3.8-4.5C12,3.9,12.4,3.9,12.7,4.1z"/></svg>';

    // Render based on selected style
    error_log('[WPCC] Checking style condition: $style = ' . var_export($style, true));
    if ($style === 'a'):
        error_log('[WPCC] Style condition TRUE - rendering footer HTML');
        ?>
        <!-- WPCC Footer Strip Start -->
        <div class="wpcc-footer-strip wpcc-footer-a">
            <span class="wpcc-footer-copy"><?php echo esc_html($copyright); ?></span>
            <div class="wpcc-footer-links">
                <?php if ($show_terms): ?>
                    <a class="wpcc-ls-link" href="<?php echo esc_url($terms_url); ?>">Terms of Service</a>
                    <div class="wpcc-divider"></div>
                <?php endif; ?>
                <?php if ($show_privacy): ?>
                    <a class="wpcc-ls-link" href="<?php echo esc_url($privacy_url); ?>">Privacy Policy</a>
                    <div class="wpcc-divider"></div>
                <?php endif; ?>
                <?php if ($show_cookies): ?>
                    <a class="wpcc-ls-link" href="<?php echo esc_url($cookies_url); ?>">Cookie Policy</a>
                    <div class="wpcc-divider"></div>
                <?php endif; ?>
                <span class="wpcc-privacy-icon" id="wpcc-privacy-choices" style="cursor:pointer;">
                    <span class="wpcc-ccpa-icon"><?php echo $ccpa_icon; ?></span>
                    Your Privacy Choices
                </span>
            </div>
        </div>

        <!-- Privacy Choices Modal -->
        <div class="wpcc-modal-overlay" id="wpcc-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="wpcc-modal-title">
            <div class="wpcc-modal">
                <div class="wpcc-modal-header">
                    <div class="wpcc-modal-header-left">
                        <div class="wpcc-modal-eyebrow">
                            <span class="wpcc-ccpa-icon"><?php echo $ccpa_icon; ?></span>
                            <span class="wpcc-modal-eyebrow-text">California Privacy Rights · CCPA</span>
                        </div>
                        <h2 class="wpcc-modal-title" id="wpcc-modal-title">Your Privacy Choices</h2>
                    </div>
                    <button class="wpcc-modal-close" id="wpcc-modal-close" aria-label="Close privacy choices">✕</button>
                </div>

                <p class="wpcc-modal-intro">
                    Control how your data is used on this site. Changes apply to this browser only.
                    For full details see our <a href="<?php echo esc_url($privacy_url); ?>" target="_blank">Privacy Policy</a>.
                </p>

                <div class="wpcc-modal-divider"></div>

                <div class="wpcc-consent-rows">
                    <div class="wpcc-consent-row">
                        <div class="wpcc-consent-info">
                            <div class="wpcc-consent-name">
                                Strictly Necessary
                                <span class="wpcc-consent-badge wpcc-badge-required">Always on</span>
                            </div>
                            <div class="wpcc-consent-vendor">Cloudflare · Session cookies</div>
                            <div class="wpcc-consent-desc">Required for the site to function — security, load balancing, and session management. Cannot be disabled.</div>
                        </div>
                        <div class="wpcc-consent-control">
                            <label class="wpcc-toggle" aria-label="Strictly necessary cookies — always on">
                                <input type="checkbox" checked disabled>
                                <div class="wpcc-toggle-track"></div>
                                <div class="wpcc-toggle-thumb"></div>
                            </label>
                            <div class="wpcc-toggle-state wpcc-on">On</div>
                        </div>
                    </div>

                    <div class="wpcc-consent-row">
                        <div class="wpcc-consent-info">
                            <div class="wpcc-consent-name">
                                Analytics
                                <span class="wpcc-consent-badge wpcc-badge-optional">Optional</span>
                            </div>
                            <div class="wpcc-consent-vendor">Google Analytics 4 · Up to 180 days</div>
                            <div class="wpcc-consent-desc">Helps us understand how visitors use our site — pages visited, time on site, referral source. Your data is never sold to third parties.</div>
                        </div>
                        <div class="wpcc-consent-control">
                            <label class="wpcc-toggle" aria-label="Analytics cookies toggle">
                                <input type="checkbox" id="wpcc-toggle-analytics">
                                <div class="wpcc-toggle-track"></div>
                                <div class="wpcc-toggle-thumb"></div>
                            </label>
                            <div class="wpcc-toggle-state" id="wpcc-state-analytics">Off</div>
                        </div>
                    </div>
                </div>

                <div class="wpcc-modal-footer">
                    <div class="wpcc-modal-actions">
                        <button class="wpcc-modal-btn wpcc-modal-btn-reject" id="wpcc-modal-reject">Reject All</button>
                        <button class="wpcc-modal-btn wpcc-modal-btn-save" id="wpcc-modal-save">Save My Choices</button>
                    </div>
                    <p class="wpcc-modal-legal">
                        Applies to this browser only. To reset, clear your cookies or return to this modal.
                    </p>
                </div>
            </div>
        </div>

        <!-- Toast notification -->
        <div class="wpcc-toast" id="wpcc-toast"></div>
    <?php endif;
}

// Get banner CSS
function wpcc_get_banner_styles() {
    $banner_bg = get_option('wpcc_banner_bg_color', '#ffffff');
    $banner_text = get_option('wpcc_banner_text_color', '#111111');
    $accept_bg = get_option('wpcc_accept_bg_color', '#111111');
    $accept_text = get_option('wpcc_accept_text_color', '#ffffff');
    $reject_border = get_option('wpcc_reject_border_color', '#111111');

    return '
    /* ── Pill container ── */
    .wpcc-banner {
        position: fixed;
        bottom: 1.5rem;
        left: 50%;
        transform: translateX(-50%);
        z-index: 999999;
        max-width: calc(100% - 2rem);

        display: flex;
        align-items: center;
        gap: 0.75rem;
        flex-wrap: nowrap;
        white-space: nowrap;

        padding: 0.5rem 0.65rem 0.5rem 1rem;
        border-radius: 100px;

        background: ' . esc_attr($banner_bg) . ';
        color: ' . esc_attr($banner_text) . ';
        border: 1px solid rgba(0,0,0,0.10);
        box-shadow: 0 4px 24px rgba(0,0,0,0.10), 0 1px 4px rgba(0,0,0,0.06);

        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);

        font-size: 0.8rem;
        line-height: 1.4;
    }

    /* ── Inline text + link ── */
    .wpcc-banner__text {
        color: ' . esc_attr($banner_text) . ';
        opacity: 0.72;
    }

    .wpcc-banner__link {
        color: ' . esc_attr($banner_text) . ';
        opacity: 1;
        text-decoration: underline;
        text-underline-offset: 2px;
        text-decoration-thickness: 1px;
        margin-left: 0.15rem;
    }

    .wpcc-banner__link:hover {
        opacity: 0.7;
    }

    /* ── Button row ── */
    .wpcc-banner__actions {
        display: flex;
        gap: 0.35rem;
        flex-shrink: 0;
    }

    /* ── Shared button base ── */
    .wpcc-btn {
        font-size: 0.75rem;
        font-weight: 500;
        letter-spacing: 0.03em;
        padding: 0.45rem 1rem;
        border-radius: 100px;
        border: 1px solid transparent;
        cursor: pointer;
        white-space: nowrap;
        min-height: 0;
        min-width: 0;
        transition: opacity 0.15s ease, transform 0.1s ease;
        line-height: 1;
        font-family: inherit;
    }

    .wpcc-btn:active {
        transform: scale(0.97);
    }

    /* ── Accept (filled) ── */
    .wpcc-btn--primary {
        background: ' . esc_attr($accept_bg) . ';
        color: ' . esc_attr($accept_text) . ';
        border-color: ' . esc_attr($accept_bg) . ';
    }

    .wpcc-btn--primary:hover {
        opacity: 0.85;
    }

    .wpcc-btn--primary:focus-visible {
        outline: 2px solid #005FCC;
        outline-offset: 2px;
    }

    /* ── Reject (outline — same visual weight as accept) ── */
    .wpcc-btn--secondary {
        background: transparent;
        color: ' . esc_attr($banner_text) . ';
        border-color: ' . esc_attr($reject_border) . ';
        opacity: 0.65;
    }

    .wpcc-btn--secondary:hover {
        opacity: 1;
    }

    .wpcc-btn--secondary:focus-visible {
        outline: 2px solid #005FCC;
        outline-offset: 2px;
    }

    /* ── Tablet: allow wrapping but keep pill shape ── */
    @media (max-width: 768px) {
        .wpcc-banner {
            max-width: calc(100% - 1.5rem);
            white-space: normal;
            flex-wrap: wrap;
            padding: 0.65rem 0.75rem 0.65rem 1rem;
            gap: 0.6rem;
        }

        .wpcc-banner__text {
            flex: 1 1 auto;
            min-width: 200px;
        }

        .wpcc-banner__actions {
            gap: 0.4rem;
        }

        .wpcc-btn {
            padding: 0.5rem 1rem;
            font-size: 0.75rem;
        }
    }

    /* ── Mobile: full-width bottom bar ── */
    @media (max-width: 600px) {
        .wpcc-banner {
            bottom: 0;
            left: 0;
            right: 0;
            max-width: none;
            transform: none;
            border-radius: 0;
            border-top: 1px solid rgba(0,0,0,0.08);
            border-left: none;
            border-right: none;
            border-bottom: none;
            box-shadow: 0 -2px 12px rgba(0,0,0,0.08);
            padding: 0.85rem 1rem;
            gap: 0.65rem;
        }

        .wpcc-banner__text {
            flex: 1 1 100%;
            min-width: 0;
        }

        .wpcc-banner__actions {
            width: 100%;
            gap: 0.5rem;
        }

        .wpcc-btn {
            flex: 1;
            padding: 0.6rem 1rem;
            font-size: 0.8rem;
            border-radius: 6px;
            text-align: center;
        }
    }

    /* ══════════════════════════════════════════════
       FOOTER STRIP (USA/CCPA)
       ══════════════════════════════════════════════ */

    /* Shared link styles */
    .wpcc-ls-link {
        font-size: 0.7rem;
        letter-spacing: 0.03em;
        text-decoration: none;
        white-space: nowrap;
        transition: opacity 0.15s;
        cursor: pointer;
    }
    .wpcc-ls-link:hover { opacity: 0.6; }

    .wpcc-privacy-icon {
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        font-size: 0.7rem;
        white-space: nowrap;
        transition: opacity 0.15s;
    }
    .wpcc-privacy-icon:hover { opacity: 0.7; }

    /* CCPA icon */
    .wpcc-ccpa-icon {
        display: inline-flex;
        align-items: center;
        flex-shrink: 0;
        line-height: 1;
    }
    .wpcc-ccpa-icon svg {
        height: 14px;
        width: auto;
        vertical-align: middle;
    }

    /* Variant A: Dark minimal single line */
    .wpcc-footer-a {
        position: relative;
        width: 100%;
        margin: 0;
        background: ' . esc_attr(get_option('wpcc_footer_bg_color', '#0d0b08')) . ';
        color: ' . esc_attr(get_option('wpcc_footer_text_color', 'rgba(255,255,255,0.38)')) . ';
        padding: 0 2rem;
        height: 38px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        border-top: 1px solid rgba(255,255,255,0.05);
        flex-wrap: nowrap;
        overflow: hidden;
        box-sizing: border-box;
    }

    .wpcc-footer-copy {
        font-size: 0.65rem;
        letter-spacing: 0.04em;
        flex-shrink: 0;
        opacity: 0.5;
    }

    .wpcc-footer-links {
        display: flex;
        align-items: center;
        gap: 1.5rem;
        flex-wrap: nowrap;
    }

    .wpcc-footer-a .wpcc-ls-link {
        color: rgba(255,255,255,0.38);
    }

    .wpcc-footer-a .wpcc-privacy-icon {
        color: rgba(255,255,255,0.5);
    }

    .wpcc-divider {
        width: 1px;
        height: 10px;
        background: rgba(255,255,255,0.12);
        flex-shrink: 0;
    }

    /* Mobile responsive */
    @media (max-width: 768px) {
        .wpcc-footer-a {
            height: auto;
            flex-direction: column;
            align-items: flex-start;
            padding: 0.85rem 1.5rem;
            gap: 0.6rem;
        }

        .wpcc-footer-links {
            flex-wrap: wrap;
            gap: 1rem;
        }

        .wpcc-divider {
            display: none;
        }
    }

    /* ══════════════════════════════════════════════
       PRIVACY CHOICES MODAL
       ══════════════════════════════════════════════ */
    .wpcc-modal-overlay {
        position: fixed;
        inset: 0;
        background: rgba(8, 6, 3, 0.75);
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(6px);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 1.5rem;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.28s ease;
    }
    .wpcc-modal-overlay.wpcc-open {
        opacity: 1;
        pointer-events: auto;
    }

    .wpcc-modal {
        background: #1a1610;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 16px;
        width: 100%;
        max-width: 480px;
        box-shadow: 0 32px 80px rgba(0,0,0,0.7), 0 2px 8px rgba(0,0,0,0.4);
        transform: translateY(16px) scale(0.98);
        transition: transform 0.35s cubic-bezier(0.22, 1, 0.36, 1);
        overflow: hidden;
    }
    .wpcc-modal-overlay.wpcc-open .wpcc-modal {
        transform: translateY(0) scale(1);
    }

    .wpcc-modal-header {
        padding: 1.5rem 1.5rem 0;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1rem;
    }
    .wpcc-modal-header-left {
        display: flex;
        flex-direction: column;
        gap: 0.4rem;
    }
    .wpcc-modal-eyebrow {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .wpcc-modal-eyebrow-text {
        font-size: 0.6rem;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        color: #5a5040;
        font-weight: 500;
    }
    .wpcc-modal-title {
        font-size: 1.35rem;
        font-weight: 400;
        color: #f0ece4;
        line-height: 1.2;
        letter-spacing: 0.01em;
    }
    .wpcc-modal-close {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.07);
        border-radius: 50%;
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: rgba(255,255,255,0.35);
        font-size: 0.9rem;
        flex-shrink: 0;
        margin-top: 2px;
        transition: background 0.15s, color 0.15s;
        line-height: 1;
    }
    .wpcc-modal-close:hover {
        background: rgba(255,255,255,0.1);
        color: rgba(255,255,255,0.7);
    }

    .wpcc-modal-intro {
        padding: 0.75rem 1.5rem 0;
        font-size: 0.73rem;
        color: #7a6a58;
        line-height: 1.65;
    }
    .wpcc-modal-intro a {
        color: #c8b89a;
        text-decoration: underline;
        text-underline-offset: 2px;
        text-decoration-thickness: 1px;
    }

    .wpcc-modal-divider {
        height: 1px;
        background: rgba(255,255,255,0.05);
        margin: 1.25rem 1.5rem 0;
    }

    .wpcc-consent-rows {
        padding: 0 1.5rem;
    }

    .wpcc-consent-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1.25rem;
        padding: 1rem 0;
        border-bottom: 1px solid rgba(255,255,255,0.04);
    }
    .wpcc-consent-row:last-child {
        border-bottom: none;
    }

    .wpcc-consent-info {
        flex: 1;
        min-width: 0;
    }

    .wpcc-consent-name {
        font-size: 0.8rem;
        font-weight: 500;
        color: #e0d8cc;
        margin-bottom: 0.25rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .wpcc-consent-badge {
        font-size: 0.55rem;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        padding: 0.15rem 0.45rem;
        border-radius: 3px;
        font-weight: 500;
    }
    .wpcc-badge-required {
        background: rgba(74,158,107,0.12);
        color: #5aae7a;
        border: 1px solid rgba(74,158,107,0.2);
    }
    .wpcc-badge-optional {
        background: rgba(200,184,154,0.08);
        color: #8a7a68;
        border: 1px solid rgba(200,184,154,0.1);
    }

    .wpcc-consent-vendor {
        font-size: 0.65rem;
        color: #5a4e40;
        margin-bottom: 0.3rem;
        letter-spacing: 0.02em;
    }
    .wpcc-consent-desc {
        font-size: 0.7rem;
        color: #6a5e50;
        line-height: 1.55;
    }

    .wpcc-consent-control {
        flex-shrink: 0;
        padding-top: 2px;
    }

    .wpcc-toggle {
        position: relative;
        width: 42px;
        height: 24px;
        display: block;
    }
    .wpcc-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
        position: absolute;
    }
    .wpcc-toggle-track {
        position: absolute;
        inset: 0;
        background: #2a2018;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 12px;
        cursor: pointer;
        transition: background 0.22s, border-color 0.22s;
    }
    .wpcc-toggle input:checked + .wpcc-toggle-track {
        background: #c8b89a;
        border-color: #c8b89a;
    }
    .wpcc-toggle input:disabled + .wpcc-toggle-track {
        cursor: not-allowed;
        opacity: 0.5;
    }
    .wpcc-toggle-thumb {
        position: absolute;
        top: 3px;
        left: 3px;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: #6a5a48;
        box-shadow: 0 1px 3px rgba(0,0,0,0.4);
        transition: transform 0.22s cubic-bezier(0.22, 1, 0.36, 1), background 0.22s;
        pointer-events: none;
    }
    .wpcc-toggle input:checked ~ .wpcc-toggle-thumb {
        transform: translateX(18px);
        background: #1a1610;
    }

    .wpcc-toggle-state {
        font-size: 0.58rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #3a3028;
        margin-top: 5px;
        text-align: center;
        transition: color 0.2s;
        font-weight: 500;
    }
    .wpcc-toggle-state.wpcc-on {
        color: #8a7a62;
    }

    .wpcc-modal-footer {
        padding: 1.25rem 1.5rem 1.5rem;
        background: rgba(0,0,0,0.2);
        border-top: 1px solid rgba(255,255,255,0.04);
        display: flex;
        flex-direction: column;
        gap: 0.85rem;
    }

    .wpcc-modal-actions {
        display: flex;
        gap: 0.6rem;
    }

    .wpcc-modal-btn {
        flex: 1;
        font-size: 0.73rem;
        font-weight: 400;
        letter-spacing: 0.04em;
        padding: 0.65rem 1rem;
        border-radius: 8px;
        cursor: pointer;
        transition: opacity 0.15s, transform 0.1s;
        border: 1px solid transparent;
        line-height: 1;
        font-family: inherit;
    }
    .wpcc-modal-btn:active {
        transform: scale(0.98);
    }

    .wpcc-modal-btn-reject {
        background: transparent;
        color: #6a5e50;
        border-color: rgba(255,255,255,0.07);
    }
    .wpcc-modal-btn-reject:hover {
        color: #a09080;
        border-color: rgba(255,255,255,0.15);
    }

    .wpcc-modal-btn-save {
        background: #c8b89a;
        color: #1a1610;
        border-color: #c8b89a;
        font-weight: 500;
    }
    .wpcc-modal-btn-save:hover {
        opacity: 0.88;
    }

    .wpcc-modal-legal {
        font-size: 0.62rem;
        color: #3a3028;
        line-height: 1.6;
        text-align: center;
    }
    .wpcc-modal-legal a {
        color: #5a5040;
        text-decoration: underline;
        text-underline-offset: 2px;
    }

    .wpcc-toast {
        position: fixed;
        bottom: 2rem;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: #2a2018;
        border: 1px solid rgba(200,184,154,0.15);
        color: #c8b89a;
        font-size: 0.72rem;
        padding: 0.6rem 1.2rem;
        border-radius: 100px;
        letter-spacing: 0.04em;
        opacity: 0;
        transition: opacity 0.25s, transform 0.25s;
        pointer-events: none;
        white-space: nowrap;
        z-index: 999999;
    }
    .wpcc-toast.wpcc-show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
    ';
}

// Get consent JavaScript
function wpcc_get_consent_script() {
    return "
    (function() {
        'use strict';

        const CONSENT_KEY = 'wpcc_consent';
        const banner = document.getElementById('wpcc-banner');
        const acceptBtn = document.getElementById('wpcc-accept');
        const rejectBtn = document.getElementById('wpcc-reject');
        const config = window.wpccConfig || {};

        // Check if consent exists and is valid
        function hasValidConsent() {
            try {
                const stored = localStorage.getItem(CONSENT_KEY);
                if (!stored) {
                    console.log('[WPCC] No stored consent found');
                    return null;
                }

                const data = JSON.parse(stored);
                const now = Date.now();

                if (now > data.expires) {
                    console.log('[WPCC] Stored consent expired');
                    localStorage.removeItem(CONSENT_KEY);
                    return null;
                }

                console.log('[WPCC] Valid consent found:', data.value);
                return data.value; // 'accepted' or 'rejected'
            } catch (e) {
                console.error('[WPCC] Error reading consent:', e);
                return null;
            }
        }

        // Save consent decision
        function saveConsent(value) {
            const expiryMs = (config.expiryDays || 180) * 24 * 60 * 60 * 1000;
            const data = {
                value: value,
                expires: Date.now() + expiryMs
            };
            localStorage.setItem(CONSENT_KEY, JSON.stringify(data));
            console.log('[WPCC] Consent saved:', value, '(expires in ' + config.expiryDays + ' days)');
        }

        // Load GA4 tracking
        function loadGA4() {
            if (!config.ga4Id) {
                console.log('[WPCC] No GA4 ID configured - skipping GA4 load');
                return;
            }

            // Check if already loaded
            if (document.querySelector('script[src*=\"' + config.ga4Id + '\"]')) {
                console.log('[WPCC] GA4 already loaded');
                return;
            }

            console.log('[WPCC] Loading GA4 tracking with ID:', config.ga4Id);

            // Create and append GA4 script
            const script = document.createElement('script');
            script.async = true;
            script.src = 'https://www.googletagmanager.com/gtag/js?id=' + config.ga4Id;
            document.head.appendChild(script);

            // Update consent mode
            if (typeof gtag === 'function') {
                gtag('consent', 'update', {
                    'analytics_storage': 'granted'
                });
                gtag('config', config.ga4Id);
                console.log('[WPCC] GA4 consent updated to GRANTED');
            } else {
                console.warn('[WPCC] gtag function not available yet - consent will update when GA4 loads');
            }
        }

        // Show banner
        function showBanner() {
            if (banner) {
                console.log('[WPCC] Showing cookie consent banner');
                banner.style.display = 'block';
                // Focus on first button (reject) for accessibility
                setTimeout(function() {
                    if (rejectBtn) rejectBtn.focus();
                }, 100);
            }
        }

        // Hide banner
        function hideBanner() {
            if (banner) {
                console.log('[WPCC] Hiding banner');
                banner.style.display = 'none';
            }
        }

        // Handle accept
        function handleAccept() {
            console.log('[WPCC] User clicked ACCEPT');
            saveConsent('accepted');
            loadGA4();
            hideBanner();
        }

        // Handle reject
        function handleReject() {
            console.log('[WPCC] User clicked REJECT - GA4 will NOT be loaded');
            saveConsent('rejected');
            hideBanner();
        }

        // Initialize
        function init() {
            console.log('[WPCC] Initializing cookie consent system (mode: ' + config.mode + ')');
            const consent = hasValidConsent();

            // GDPR/Banner mode: show banner if no consent
            if (config.mode === 'banner') {
                if (consent === 'accepted') {
                    console.log('[WPCC] Previous consent: ACCEPTED - loading GA4');
                    loadGA4();
                } else if (consent === null) {
                    console.log('[WPCC] No previous consent - showing banner');
                    showBanner();
                } else {
                    console.log('[WPCC] Previous consent: REJECTED - GA4 will not load');
                }
            }
            // Footer mode (USA/CCPA): opt-in model, load GA4 only if previously accepted
            else if (config.mode === 'footer') {
                if (consent === 'accepted') {
                    console.log('[WPCC] Previous consent: ACCEPTED - loading GA4');
                    loadGA4();
                } else {
                    console.log('[WPCC] Footer mode: No consent or rejected. User can opt-in via Privacy Choices link.');
                }

                // Modal functions
                function wpccOpenModal() {
                    const overlay = document.getElementById('wpcc-modal-overlay');
                    const toggle = document.getElementById('wpcc-toggle-analytics');

                    // Set toggle state from current consent
                    const currentConsent = hasValidConsent();
                    if (currentConsent === 'accepted') {
                        toggle.checked = true;
                        wpccUpdateToggleState(toggle, true);
                    } else {
                        toggle.checked = false;
                        wpccUpdateToggleState(toggle, false);
                    }

                    overlay.classList.add('wpcc-open');

                    // Focus first interactive element
                    setTimeout(function() {
                        toggle.focus();
                    }, 350);
                }

                function wpccCloseModal() {
                    document.getElementById('wpcc-modal-overlay').classList.remove('wpcc-open');
                }

                function wpccUpdateToggleState(input, checked) {
                    const stateEl = document.getElementById('wpcc-state-analytics');
                    if (stateEl) {
                        stateEl.textContent = checked ? 'On' : 'Off';
                        if (checked) {
                            stateEl.classList.add('wpcc-on');
                        } else {
                            stateEl.classList.remove('wpcc-on');
                        }
                    }
                }

                function wpccShowToast(msg) {
                    const toast = document.getElementById('wpcc-toast');
                    if (toast) {
                        toast.textContent = msg;
                        toast.classList.add('wpcc-show');
                        setTimeout(function() {
                            toast.classList.remove('wpcc-show');
                        }, 2800);
                    }
                }

                function wpccModalReject() {
                    saveConsent('rejected');
                    wpccCloseModal();
                    wpccShowToast('Preferences saved — analytics off');
                }

                function wpccModalSave() {
                    const analytics = document.getElementById('wpcc-toggle-analytics').checked;
                    if (analytics) {
                        saveConsent('accepted');
                        loadGA4();
                        wpccShowToast('Preferences saved — analytics on');
                    } else {
                        saveConsent('rejected');
                        wpccShowToast('Preferences saved — analytics off');
                    }
                    wpccCloseModal();
                }

                // Attach modal events
                const privacyChoices = document.getElementById('wpcc-privacy-choices');
                if (privacyChoices) {
                    privacyChoices.addEventListener('click', wpccOpenModal);
                }

                const modalClose = document.getElementById('wpcc-modal-close');
                if (modalClose) {
                    modalClose.addEventListener('click', wpccCloseModal);
                }

                const modalOverlay = document.getElementById('wpcc-modal-overlay');
                if (modalOverlay) {
                    modalOverlay.addEventListener('click', function(e) {
                        if (e.target === this) wpccCloseModal();
                    });
                    document.addEventListener('keydown', function(e) {
                        if (e.key === 'Escape' && modalOverlay.classList.contains('wpcc-open')) {
                            wpccCloseModal();
                        }
                    });
                }

                const modalReject = document.getElementById('wpcc-modal-reject');
                if (modalReject) {
                    modalReject.addEventListener('click', wpccModalReject);
                }

                const modalSave = document.getElementById('wpcc-modal-save');
                if (modalSave) {
                    modalSave.addEventListener('click', wpccModalSave);
                }

                const toggleAnalytics = document.getElementById('wpcc-toggle-analytics');
                if (toggleAnalytics) {
                    toggleAnalytics.addEventListener('change', function() {
                        wpccUpdateToggleState(this, this.checked);
                    });
                }
            }
        }

        // Event listeners (for GDPR banner)
        if (acceptBtn) {
            acceptBtn.addEventListener('click', handleAccept);
        }

        if (rejectBtn) {
            rejectBtn.addEventListener('click', handleReject);
        }

        // Run on DOM ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            init();
        }
    })();
    ";
}

// ============================================
// ADMIN INTERFACE
// ============================================

// Add admin menu
add_action('admin_menu', 'wpcc_add_admin_menu');
function wpcc_add_admin_menu() {
    add_menu_page(
        'Cookie Consent',
        'Cookie Consent',
        'manage_options',
        'wp-cookie-consent',
        'wpcc_admin_page',
        'dashicons-privacy',
        30
    );

    add_submenu_page(
        'wp-cookie-consent',
        'Settings',
        'Settings',
        'manage_options',
        'wpcc-settings',
        'wpcc_settings_page'
    );
}

// Register settings
add_action('admin_init', 'wpcc_register_settings');
function wpcc_register_settings() {
    register_setting('wpcc_settings_group', 'wpcc_enabled');
    register_setting('wpcc_settings_group', 'wpcc_ga4_id');
    register_setting('wpcc_settings_group', 'wpcc_banner_title');
    register_setting('wpcc_settings_group', 'wpcc_banner_body');
    register_setting('wpcc_settings_group', 'wpcc_accept_label');
    register_setting('wpcc_settings_group', 'wpcc_reject_label');
    register_setting('wpcc_settings_group', 'wpcc_consent_expiry_days');

    // Color settings (banner)
    register_setting('wpcc_settings_group', 'wpcc_banner_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_banner_text_color');
    register_setting('wpcc_settings_group', 'wpcc_accept_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_accept_text_color');
    register_setting('wpcc_settings_group', 'wpcc_reject_border_color');

    // Learn more link
    register_setting('wpcc_settings_group', 'wpcc_learn_more_url');

    // Geolocation settings
    register_setting('wpcc_settings_group', 'wpcc_usa_mode');
    register_setting('wpcc_settings_group', 'wpcc_fallback_mode');

    // Footer strip settings (USA/CCPA)
    register_setting('wpcc_settings_group', 'wpcc_footer_style');
    register_setting('wpcc_settings_group', 'wpcc_footer_copyright');
    register_setting('wpcc_settings_group', 'wpcc_footer_show_terms');
    register_setting('wpcc_settings_group', 'wpcc_footer_terms_url');
    register_setting('wpcc_settings_group', 'wpcc_footer_show_privacy');
    register_setting('wpcc_settings_group', 'wpcc_footer_privacy_url');
    register_setting('wpcc_settings_group', 'wpcc_footer_show_cookies');
    register_setting('wpcc_settings_group', 'wpcc_footer_cookies_url');
    register_setting('wpcc_settings_group', 'wpcc_footer_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_footer_text_color');
}

// Dashboard page
function wpcc_admin_page() {
    $is_enabled = get_option('wpcc_enabled', true);
    $ga4_id = get_option('wpcc_ga4_id', '');
    $has_ga4 = !empty($ga4_id);

    // Handle update cache refresh
    $cache_refreshed = false;
    if (isset($_POST['wpcc_refresh_cache']) && check_admin_referer('wpcc_refresh_cache', 'wpcc_refresh_nonce')) {
        delete_site_transient('update_plugins');
        $cache_refreshed = true;
    }
    ?>
    <div class="wrap">
        <h1>🍪 WP Cookie Consent</h1>
        <p><strong>Version:</strong> <?php echo WPCC_VERSION; ?> | <strong>Status:</strong> <?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></p>

        <?php if ($cache_refreshed): ?>
            <div class="notice notice-success is-dismissible">
                <p><strong>Update cache cleared!</strong> WordPress will check for plugin updates now.</p>
            </div>
        <?php endif; ?>

        <div class="card" style="max-width: 800px;">
            <h2>Plugin Status</h2>
            <table class="widefat" style="margin-top: 10px;">
                <tbody>
                    <tr>
                        <td style="width: 200px;"><strong>Cookie Banner:</strong></td>
                        <td><?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>GA4 Tracking ID:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ ' . esc_html($ga4_id) . '</span>' : '<span style="color: #f56e28;">⚠ Not configured</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Consent Mode v2:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ Ready</span>' : '<span style="color: #999;">○ Waiting for GA4 ID</span>'; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>🚀 Quick Start</h3>
            <ol>
                <li>Go to <a href="<?php echo admin_url('admin.php?page=wpcc-settings'); ?>">Settings</a> to configure your GA4 tracking ID</li>
                <li>Customize the cookie banner text and appearance</li>
                <li>Test the banner on your site (it will appear for first-time visitors)</li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>🔄 Update Cache Management</h3>
            <p>Use this button to clear the WordPress update cache and force a check for new plugin versions from GitHub.</p>
            <form method="post" style="margin-top: 15px;">
                <?php wp_nonce_field('wpcc_refresh_cache', 'wpcc_refresh_nonce'); ?>
                <button type="submit" name="wpcc_refresh_cache" class="button button-secondary">
                    🔄 Refresh Update Cache
                </button>
                <p class="description" style="margin-top: 10px;">Click this button after pushing a new release to GitHub to check for updates immediately.</p>
            </form>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 What's in v<?php echo WPCC_VERSION; ?></h3>
            <ul>
                <li><strong>GDPR-compliant cookie consent management</strong></li>
                <li><strong>Google Analytics 4 (GA4) integration with Consent Mode v2</strong></li>
                <li><strong>Equal prominence Accept/Reject buttons</strong> - no dark patterns</li>
                <li><strong>Auto-updates via GitHub</strong> - always get the latest version</li>
                <li><strong>Zero external dependencies</strong> - works on any WordPress site</li>
            </ul>
        </div>
    </div>
    <?php
}

// Settings page
function wpcc_settings_page() {
    if (isset($_POST['wpcc_settings_submit'])) {
        check_admin_referer('wpcc_settings_save', 'wpcc_settings_nonce');

        // Sanitize and save all settings
        update_option('wpcc_enabled', isset($_POST['wpcc_enabled']) ? 1 : 0);
        update_option('wpcc_ga4_id', sanitize_text_field($_POST['wpcc_ga4_id']));
        update_option('wpcc_banner_title', sanitize_text_field($_POST['wpcc_banner_title']));
        update_option('wpcc_banner_body', wp_kses_post($_POST['wpcc_banner_body']));
        update_option('wpcc_accept_label', sanitize_text_field($_POST['wpcc_accept_label']));
        update_option('wpcc_reject_label', sanitize_text_field($_POST['wpcc_reject_label']));
        update_option('wpcc_consent_expiry_days', absint($_POST['wpcc_consent_expiry_days']));

        // Color settings (banner)
        update_option('wpcc_banner_bg_color', sanitize_hex_color($_POST['wpcc_banner_bg_color']));
        update_option('wpcc_banner_text_color', sanitize_hex_color($_POST['wpcc_banner_text_color']));
        update_option('wpcc_accept_bg_color', sanitize_hex_color($_POST['wpcc_accept_bg_color']));
        update_option('wpcc_accept_text_color', sanitize_hex_color($_POST['wpcc_accept_text_color']));
        update_option('wpcc_reject_border_color', sanitize_hex_color($_POST['wpcc_reject_border_color']));

        // Learn more link
        update_option('wpcc_learn_more_url', esc_url_raw($_POST['wpcc_learn_more_url']));

        // Geolocation settings
        update_option('wpcc_usa_mode', sanitize_text_field($_POST['wpcc_usa_mode']));
        update_option('wpcc_fallback_mode', sanitize_text_field($_POST['wpcc_fallback_mode']));

        // Footer strip settings
        update_option('wpcc_footer_style', sanitize_text_field($_POST['wpcc_footer_style']));
        update_option('wpcc_footer_copyright', sanitize_text_field($_POST['wpcc_footer_copyright']));
        update_option('wpcc_footer_show_terms', isset($_POST['wpcc_footer_show_terms']) ? 1 : 0);
        update_option('wpcc_footer_terms_url', esc_url_raw($_POST['wpcc_footer_terms_url']));
        update_option('wpcc_footer_show_privacy', isset($_POST['wpcc_footer_show_privacy']) ? 1 : 0);
        update_option('wpcc_footer_privacy_url', esc_url_raw($_POST['wpcc_footer_privacy_url']));
        update_option('wpcc_footer_show_cookies', isset($_POST['wpcc_footer_show_cookies']) ? 1 : 0);
        update_option('wpcc_footer_cookies_url', esc_url_raw($_POST['wpcc_footer_cookies_url']));
        update_option('wpcc_footer_bg_color', sanitize_text_field($_POST['wpcc_footer_bg_color']));
        update_option('wpcc_footer_text_color', sanitize_text_field($_POST['wpcc_footer_text_color']));

        echo '<div class="notice notice-success is-dismissible"><p><strong>Settings saved successfully!</strong></p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Cookie Consent Settings</h1>
        <p>Configure your GDPR-compliant cookie consent banner and Google Analytics integration.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpcc_settings_save', 'wpcc_settings_nonce'); ?>

            <h2>General Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_enabled">Enable Cookie Banner</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpcc_enabled" id="wpcc_enabled" value="1" <?php checked(get_option('wpcc_enabled', true)); ?>>
                            Show cookie consent banner on the site
                        </label>
                        <p class="description">Master on/off switch for the entire cookie consent system.</p>
                    </td>
                </tr>
            </table>

            <h2>Geolocation Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label>Current Visitor</label>
                    </th>
                    <td>
                        <?php
                        $country = wpcc_get_country_code();
                        $is_gdpr = wpcc_is_gdpr_country($country);
                        $mode = wpcc_get_consent_mode();
                        ?>
                        <p style="margin: 0; padding: 0.5rem; background: #f0f6fc; border-left: 3px solid #0969da; display: inline-block;">
                            <strong>Country Code:</strong> <?php echo $country ? esc_html($country) : 'Unknown (Cloudflare header not detected)'; ?><br>
                            <strong>GDPR Country:</strong> <?php echo $is_gdpr ? '✓ Yes' : '✗ No'; ?><br>
                            <strong>UI Mode:</strong> <?php echo esc_html(ucfirst($mode)); ?>
                        </p>
                        <p class="description">
                            This plugin uses Cloudflare's HTTP_CF_IPCOUNTRY header to detect visitor location.<br>
                            <strong>GDPR countries (EU/EEA/UK):</strong> Show full cookie consent banner<br>
                            <strong>USA:</strong> Show "Your Privacy Choices" footer strip (CCPA compliant)<br>
                            <strong>Others:</strong> Use fallback mode (banner for safety)
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_usa_mode">USA Visitor Mode</label>
                    </th>
                    <td>
                        <select name="wpcc_usa_mode" id="wpcc_usa_mode">
                            <option value="footer" <?php selected(get_option('wpcc_usa_mode', 'footer'), 'footer'); ?>>Footer Strip (CCPA - recommended)</option>
                            <option value="banner" <?php selected(get_option('wpcc_usa_mode', 'footer'), 'banner'); ?>>Full Banner (GDPR-style)</option>
                        </select>
                        <p class="description">Choose what USA visitors see. Footer strip is CCPA-compliant and less intrusive.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_fallback_mode">Fallback Mode</label>
                    </th>
                    <td>
                        <select name="wpcc_fallback_mode" id="wpcc_fallback_mode">
                            <option value="banner" <?php selected(get_option('wpcc_fallback_mode', 'banner'), 'banner'); ?>>Banner (safer for compliance)</option>
                            <option value="footer" <?php selected(get_option('wpcc_fallback_mode', 'banner'), 'footer'); ?>>Footer Strip</option>
                        </select>
                        <p class="description">What to show when geolocation is unavailable (no Cloudflare header detected).</p>
                    </td>
                </tr>
            </table>

            <h2>Google Analytics Configuration</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_ga4_id">GA4 Measurement ID</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_ga4_id" id="wpcc_ga4_id" value="<?php echo esc_attr(get_option('wpcc_ga4_id', '')); ?>" class="regular-text" placeholder="G-XXXXXXXXXX">
                        <p class="description">Enter your Google Analytics 4 Measurement ID (format: G-XXXXXXXXXX). Leave empty to disable GA4 tracking.</p>
                    </td>
                </tr>
            </table>

            <h2>Banner Content</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_title">Banner Title</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_banner_title" id="wpcc_banner_title" value="<?php echo esc_attr(get_option('wpcc_banner_title', 'We use cookies')); ?>" class="regular-text">
                        <p class="description">Note: the title is hidden in the pill layout. Use the body text field only.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_body">Banner Message</label>
                    </th>
                    <td>
                        <textarea name="wpcc_banner_body" id="wpcc_banner_body" rows="4" class="large-text"><?php echo esc_textarea(get_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.')); ?></textarea>
                        <p class="description">The main message displayed in the cookie banner. HTML allowed (links, bold, etc.).</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_label">Accept Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_accept_label" id="wpcc_accept_label" value="<?php echo esc_attr(get_option('wpcc_accept_label', 'Accept')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_reject_label">Reject Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_reject_label" id="wpcc_reject_label" value="<?php echo esc_attr(get_option('wpcc_reject_label', 'Reject')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_learn_more_url">"Learn More" Link URL</label>
                    </th>
                    <td>
                        <input type="url" name="wpcc_learn_more_url" id="wpcc_learn_more_url" value="<?php echo esc_attr(get_option('wpcc_learn_more_url', '/privacy-policy#cookies')); ?>" class="regular-text" placeholder="/privacy-policy#cookies">
                        <p class="description">URL for the "Learn more" link in the banner. Can be a relative path (e.g., /privacy-policy#cookies) or full URL.</p>
                    </td>
                </tr>
            </table>

            <h2>Appearance & Colors</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_bg_color">Banner Background</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_banner_bg_color" id="wpcc_banner_bg_color" value="<?php echo esc_attr(get_option('wpcc_banner_bg_color', '#ffffff')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_banner_bg_color', '#ffffff')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Background color of the cookie banner.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_text_color">Banner Text</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_banner_text_color" id="wpcc_banner_text_color" value="<?php echo esc_attr(get_option('wpcc_banner_text_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_banner_text_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Text color in the banner.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_bg_color">Accept Button Background</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_accept_bg_color" id="wpcc_accept_bg_color" value="<?php echo esc_attr(get_option('wpcc_accept_bg_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_accept_bg_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Background color of the Accept button.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_text_color">Accept Button Text</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_accept_text_color" id="wpcc_accept_text_color" value="<?php echo esc_attr(get_option('wpcc_accept_text_color', '#ffffff')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_accept_text_color', '#ffffff')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Text color of the Accept button.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_reject_border_color">Reject Button Border</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_reject_border_color" id="wpcc_reject_border_color" value="<?php echo esc_attr(get_option('wpcc_reject_border_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_reject_border_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Border and text color of the Reject button.</p>
                    </td>
                </tr>
            </table>

            <h2>Behavior Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_consent_expiry_days">Consent Expiry (Days)</label>
                    </th>
                    <td>
                        <input type="number" name="wpcc_consent_expiry_days" id="wpcc_consent_expiry_days" value="<?php echo esc_attr(get_option('wpcc_consent_expiry_days', 180)); ?>" min="1" max="365" class="small-text">
                        <p class="description">Number of days before asking for consent again (1-365 days).</p>
                    </td>
                </tr>
            </table>

            <h2>Footer Strip Settings (USA/CCPA)</h2>
            <p style="background: #f0f6fc; padding: 1rem; border-left: 3px solid #0969da;">
                These settings apply when <strong>USA Visitor Mode</strong> is set to "Footer Strip" (CCPA compliance).<br>
                The footer strip shows a "Your Privacy Choices" link with the official CCPA opt-out icon.
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_copyright">Copyright Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_footer_copyright" id="wpcc_footer_copyright" value="<?php echo esc_attr(get_option('wpcc_footer_copyright', '© ' . date('Y') . ' ' . get_bloginfo('name'))); ?>" class="regular-text">
                        <p class="description">Footer copyright notice (left side of footer strip).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_show_terms">Terms of Service Link</label>
                    </th>
                    <td>
                        <label style="margin-bottom: 0.5rem; display: block;">
                            <input type="checkbox" name="wpcc_footer_show_terms" id="wpcc_footer_show_terms" value="1" <?php checked(get_option('wpcc_footer_show_terms', true)); ?>>
                            Show Terms of Service link
                        </label>
                        <input type="url" name="wpcc_footer_terms_url" id="wpcc_footer_terms_url" value="<?php echo esc_attr(get_option('wpcc_footer_terms_url', '/terms-of-service')); ?>" class="regular-text" placeholder="/terms-of-service">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_show_privacy">Privacy Policy Link</label>
                    </th>
                    <td>
                        <label style="margin-bottom: 0.5rem; display: block;">
                            <input type="checkbox" name="wpcc_footer_show_privacy" id="wpcc_footer_show_privacy" value="1" <?php checked(get_option('wpcc_footer_show_privacy', true)); ?>>
                            Show Privacy Policy link
                        </label>
                        <input type="url" name="wpcc_footer_privacy_url" id="wpcc_footer_privacy_url" value="<?php echo esc_attr(get_option('wpcc_footer_privacy_url', '/privacy-policy')); ?>" class="regular-text" placeholder="/privacy-policy">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_show_cookies">Cookie Policy Link</label>
                    </th>
                    <td>
                        <label style="margin-bottom: 0.5rem; display: block;">
                            <input type="checkbox" name="wpcc_footer_show_cookies" id="wpcc_footer_show_cookies" value="1" <?php checked(get_option('wpcc_footer_show_cookies', true)); ?>>
                            Show Cookie Policy link
                        </label>
                        <input type="url" name="wpcc_footer_cookies_url" id="wpcc_footer_cookies_url" value="<?php echo esc_attr(get_option('wpcc_footer_cookies_url', '/cookie-policy')); ?>" class="regular-text" placeholder="/cookie-policy">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_bg_color">Footer Background</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_footer_bg_color" id="wpcc_footer_bg_color" value="<?php echo esc_attr(get_option('wpcc_footer_bg_color', '#0d0b08')); ?>" class="regular-text">
                        <p class="description">CSS color value (e.g., #0d0b08 or rgba(13,11,8,1)).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_text_color">Footer Text Color</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_footer_text_color" id="wpcc_footer_text_color" value="<?php echo esc_attr(get_option('wpcc_footer_text_color', 'rgba(255,255,255,0.38)')); ?>" class="regular-text">
                        <p class="description">CSS color value (e.g., rgba(255,255,255,0.38)).</p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpcc_settings_submit" class="button button-primary" value="Save Settings">
            </p>

            <script>
            // Update text inputs when color pickers change
            document.querySelectorAll('.wpcc-color-picker').forEach(function(picker) {
                picker.addEventListener('input', function() {
                    this.nextElementSibling.value = this.value;
                });
            });
            </script>
        </form>
    </div>
    <?php
}

