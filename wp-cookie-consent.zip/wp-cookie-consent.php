<?php
/**
 * Plugin Name: WP Cookie Consent
 * Plugin URI: https://github.com/hyveli/wp-cookie-consent
 * Description: GDPR-compliant cookie consent management with Google Analytics 4 (GA4) support and Consent Mode v2 integration.
 * Version: 1.0.96
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Hyveli, LLC
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-cookie-consent
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPCC_VERSION', '1.0.96');
define('WPCC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPCC_PLUGIN_URL', plugin_dir_url(__FILE__));

// ============================================
// GEOLOCATION HELPERS
// ============================================

/**
 * Get visitor's country code from Cloudflare header
 * @return string|null Two-letter country code or null if not available
 */
function wpcc_get_country_code() {
    return $_SERVER['HTTP_CF_IPCOUNTRY'] ?? null;
}

/**
 * Check if a country code is in GDPR jurisdiction
 * @param string|null $code Two-letter country code
 * @return bool True if GDPR applies
 */
function wpcc_is_gdpr_country($code) {
    if (!$code) {
        return false;
    }

    $gdpr = [
        'AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR',
        'DE','GR','HU','IE','IT','LV','LT','LU','MT','NL',
        'PL','PT','RO','SK','SI','ES','SE', // EU 27
        'GB', // UK (retained GDPR post-Brexit)
        'NO','IS','LI' // EEA non-EU
    ];

    return in_array(strtoupper($code), $gdpr);
}

/**
 * Determine which consent UI to show based on geolocation
 * @return string 'banner' for GDPR banner, 'footer' for US footer strip, 'banner' as default
 */
function wpcc_get_consent_mode() {
    $country = wpcc_get_country_code();

    // If no geolocation available, show banner for safety
    if (!$country) {
        return get_option('wpcc_fallback_mode', 'banner');
    }

    // GDPR countries get the full banner
    if (wpcc_is_gdpr_country($country)) {
        return 'banner';
    }

    // USA gets footer strip (CCPA compliance)
    if (strtoupper($country) === 'US') {
        return get_option('wpcc_usa_mode', 'footer');
    }

    // All other countries default to banner
    return 'banner';
}

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    // Prevent loading the autoloader multiple times
    if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        require_once __DIR__ . '/vendor/autoload.php';
    }

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-cookie-consent-dist/main/release.json',
            __FILE__,
            'wp-cookie-consent'
        );

        // Force update check if URL parameter is present
        if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
            delete_site_transient('update_plugins');
            $updateChecker->checkForUpdates();
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>✅ Update check cache cleared! WordPress will check for updates now.</p></div>';
            });
        }
    }
}

// Activation hook
register_activation_hook(__FILE__, 'wpcc_activate');
function wpcc_activate() {
    wpcc_create_default_options();
    flush_rewrite_rules();
}

// Check for version changes and upgrade
add_action('plugins_loaded', 'wpcc_check_version');
function wpcc_check_version() {
    $installed_version = get_option('wpcc_version', '0.0.0');

    if (version_compare($installed_version, WPCC_VERSION, '<')) {
        // Version changed - run upgrade
        wpcc_upgrade($installed_version);
        update_option('wpcc_version', WPCC_VERSION);
    }
}

// ============================================
// GOOGLE SITE KIT INTEGRATION
// ============================================

/**
 * Disable Google Site Kit's automatic GTM/GA4 output
 * We'll handle consent-based loading ourselves
 */
add_action('template_redirect', 'wpcc_disable_site_kit_tracking', 1);
function wpcc_disable_site_kit_tracking() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }

    // Check if Site Kit is active
    if (!class_exists('Google\Site_Kit\Plugin') && !defined('GOOGLESITEKIT_VERSION')) {
        return;
    }

    // Disable Tag Manager module output (GTM) - multiple filter variations
    add_filter('googlesitekit_tagmanager_tag_blocked', '__return_true', 999);
    add_filter('googlesitekit_tagmanager_tag_amp_blocked', '__return_true', 999);
    add_filter('googlesitekit_gtm_tag_blocked', '__return_true', 999);

    // Disable Analytics module output (GA4) - multiple filter variations
    add_filter('googlesitekit_analytics_tag_blocked', '__return_true', 999);
    add_filter('googlesitekit_analytics_tag_amp_blocked', '__return_true', 999);
    add_filter('googlesitekit_analytics_4_tag_blocked', '__return_true', 999);
    add_filter('googlesitekit_ga4_tag_blocked', '__return_true', 999);

    // Remove Site Kit's script rendering actions entirely
    remove_action('wp_head', 'googlesitekit_analytics_tracking_opt_out', 0);
    remove_action('wp_head', 'googlesitekit_tagmanager_snippet', 0);

    // Admin notice to inform users
    if (is_admin()) {
        add_action('admin_notices', 'wpcc_site_kit_notice');
    }
}

function wpcc_site_kit_notice() {
    if (!class_exists('Google\Site_Kit\Plugin')) {
        return;
    }

    $screen = get_current_screen();
    if ($screen && $screen->id === 'toplevel_page_wp-cookie-consent') {
        echo '<div class="notice notice-info"><p><strong>WP Cookie Consent:</strong> Google Site Kit detected. GTM and GA4 auto-injection has been disabled to ensure consent compliance. Please enter your GTM/GA4 IDs in the fields below instead.</p></div>';
    }
}

// Upgrade routine
function wpcc_upgrade($from_version) {
    // Create any missing options (for upgrades from older versions)
    wpcc_create_default_options();
}

// Create default options (used by both activation and upgrade)
function wpcc_create_default_options() {
    // Core settings
    add_option('wpcc_enabled', true);
    add_option('wpcc_ga4_id', '');
    add_option('wpcc_gtm_id', '');
    add_option('wpcc_banner_title', 'We use cookies');
    add_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.');
    add_option('wpcc_accept_label', 'Accept');
    add_option('wpcc_reject_label', 'Reject');
    add_option('wpcc_consent_expiry_days', 180);

    // Color options (banner)
    add_option('wpcc_banner_bg_color', '#ffffff');
    add_option('wpcc_banner_text_color', '#111111');
    add_option('wpcc_accept_bg_color', '#111111');
    add_option('wpcc_accept_text_color', '#ffffff');
    add_option('wpcc_reject_border_color', '#111111');

    // Learn more link
    add_option('wpcc_learn_more_url', '/privacy-policy#cookies');

    // Geolocation options (v1.1.0+)
    add_option('wpcc_usa_mode', 'footer');
    add_option('wpcc_fallback_mode', 'banner');
    add_option('wpcc_disable_gdpr_banner', false);

    // Footer strip options (v1.1.0+)
    add_option('wpcc_footer_style', 'a');
    add_option('wpcc_footer_copyright_text', '© {year} {site_name} | Powered by <a href="https://marketingaid.com" target="_blank" rel="noopener noreferrer">MarketingAid</a>');
    add_option('wpcc_footer_show_terms', true);
    add_option('wpcc_footer_terms_label', 'Terms of Service');
    add_option('wpcc_footer_terms_url', '/terms-of-service');
    add_option('wpcc_footer_show_privacy', true);
    add_option('wpcc_footer_privacy_label', 'Privacy Policy');
    add_option('wpcc_footer_privacy_url', '/privacy-policy');
    add_option('wpcc_footer_show_cookies', true);
    add_option('wpcc_footer_cookies_label', 'Cookie Policy');
    add_option('wpcc_footer_cookies_url', '/cookie-policy');
    add_option('wpcc_footer_bg_color', '#0d0b08');
    add_option('wpcc_footer_text_color', 'rgba(255,255,255,0.38)');
    add_option('wpcc_footer_link_color', 'rgba(255,255,255,0.6)');
    add_option('wpcc_footer_copyright_color', 'rgba(255,255,255,0.6)');

    // CF7 Script Optimization (v1.0.7+)
    add_option('wpcc_cf7_optimize', false);
    add_option('wpcc_cf7_page_ids', '');
    add_option('wpcc_cf7_recaptcha_text', 'This site is protected by reCAPTCHA. <a href="https://policies.google.com/privacy" target="_blank">Privacy</a> - <a href="https://policies.google.com/terms" target="_blank">Terms</a>');
    add_option('wpcc_cf7_recaptcha_font_size', '11');
    add_option('wpcc_cf7_recaptcha_color', '#999999');
    add_option('wpcc_cf7_recaptcha_align', 'left');

    // reCAPTCHA v3 Integration (v1.0.93+)
    add_option('wpcc_recaptcha_enabled', false);
    add_option('wpcc_recaptcha_site_key', '');
    add_option('wpcc_recaptcha_secret_key', '');
    add_option('wpcc_recaptcha_threshold', '0.5');

    // Store current version
    add_option('wpcc_version', WPCC_VERSION);
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpcc_deactivate');
function wpcc_deactivate() {
    flush_rewrite_rules();
}

// ============================================
// CF7 SCRIPT OPTIMIZATION
// ============================================

// Prevent CF7 from loading scripts on all pages
add_filter('wpcf7_load_js', 'wpcc_disable_cf7_js', 10, 1);
add_filter('wpcf7_load_css', 'wpcc_disable_cf7_css', 10, 1);

function wpcc_disable_cf7_js($load_script) {
    // If optimization is disabled, load scripts normally
    if (!get_option('wpcc_cf7_optimize', false)) {
        return $load_script;
    }

    // Get allowed page IDs
    $allowed_pages = wpcc_get_cf7_allowed_pages();

    // If current page is in allowed list, load scripts
    if (is_page($allowed_pages) || is_single($allowed_pages)) {
        return true;
    }

    // Check if current post content has CF7 shortcode
    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'contact-form-7')) {
        return true;
    }

    // Otherwise, don't load
    return false;
}

function wpcc_disable_cf7_css($load_style) {
    // Same logic as JS
    if (!get_option('wpcc_cf7_optimize', false)) {
        return $load_style;
    }

    $allowed_pages = wpcc_get_cf7_allowed_pages();

    if (is_page($allowed_pages) || is_single($allowed_pages)) {
        return true;
    }

    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'contact-form-7')) {
        return true;
    }

    return false;
}

// Helper function to get allowed page IDs as array
function wpcc_get_cf7_allowed_pages() {
    $page_ids = get_option('wpcc_cf7_page_ids', '');

    if (empty($page_ids)) {
        return array();
    }

    // Convert comma-separated string to array of integers
    $ids = array_map('trim', explode(',', $page_ids));
    $ids = array_map('intval', $ids);
    $ids = array_filter($ids); // Remove zeros/empties

    return $ids;
}

// Output reCAPTCHA notice on CF7 pages
add_action('wp_footer', 'wpcc_output_recaptcha_notice', 99);
function wpcc_output_recaptcha_notice() {
    // Only run if reCAPTCHA is enabled
    if (!get_option('wpcc_recaptcha_enabled', false)) {
        return;
    }

    // Check if CF7 scripts are loading (means we're on a CF7 page)
    $allowed_pages = wpcc_get_cf7_allowed_pages();
    $is_cf7_page = false;

    if (is_page($allowed_pages) || is_single($allowed_pages)) {
        $is_cf7_page = true;
    }

    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'contact-form-7')) {
        $is_cf7_page = true;
    }

    if (!$is_cf7_page) {
        return;
    }

    // Get customization options
    $text = get_option('wpcc_cf7_recaptcha_text', 'This site is protected by reCAPTCHA. <a href="https://policies.google.com/privacy" target="_blank">Privacy</a> - <a href="https://policies.google.com/terms" target="_blank">Terms</a>');
    $font_size = get_option('wpcc_cf7_recaptcha_font_size', '11');
    $color = get_option('wpcc_cf7_recaptcha_color', '#999999');
    $align = get_option('wpcc_cf7_recaptcha_align', 'left');

    ?>
    <!-- WPCC reCAPTCHA Notice -->
    <style>
    /* Hide the default reCAPTCHA badge completely */
    .grecaptcha-badge {
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
    }

    /* Custom reCAPTCHA notice styling */
    .wpcc-recaptcha-notice {
        font-size: <?php echo absint($font_size); ?>px;
        color: <?php echo esc_attr($color); ?>;
        line-height: 1.5;
        margin-top: 0.75rem;
        text-align: <?php echo esc_attr($align); ?>;
    }

    .wpcc-recaptcha-notice a {
        color: <?php echo esc_attr($color); ?>;
        text-decoration: underline;
        text-underline-offset: 2px;
    }

    .wpcc-recaptcha-notice a:hover {
        opacity: 0.7;
    }
    </style>

    <script>
    (function() {
        // Wait for CF7 forms to load, then inject notice
        function injectRecaptchaNotice() {
            const forms = document.querySelectorAll('.wpcf7-form');
            if (forms.length === 0) {
                return;
            }

            forms.forEach(function(form) {
                // Check if notice already added
                if (form.querySelector('.wpcc-recaptcha-notice')) {
                    return;
                }

                // Find submit button
                const submitBtn = form.querySelector('input[type="submit"]');
                if (!submitBtn) {
                    return;
                }

                // Create notice element
                const notice = document.createElement('div');
                notice.className = 'wpcc-recaptcha-notice';
                notice.innerHTML = <?php echo json_encode(wp_kses_post($text)); ?>;

                // Insert after submit button
                submitBtn.parentNode.insertBefore(notice, submitBtn.nextSibling);
            });
        }

        // Run on DOM ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                // Initial injection
                injectRecaptchaNotice();

                // Watch for AJAX-loaded forms
                setTimeout(injectRecaptchaNotice, 500);
                setTimeout(injectRecaptchaNotice, 1000);
            });
        } else {
            injectRecaptchaNotice();
            setTimeout(injectRecaptchaNotice, 500);
        }
    })();
    </script>
    <?php
}

// ============================================
// RECAPTCHA V3 INTEGRATION
// ============================================

// Load reCAPTCHA v3 script on CF7 pages
add_action('wp_enqueue_scripts', 'wpcc_enqueue_recaptcha');
function wpcc_enqueue_recaptcha() {
    // Only run if reCAPTCHA is enabled
    if (!get_option('wpcc_recaptcha_enabled', false)) {
        return;
    }

    $site_key = get_option('wpcc_recaptcha_site_key', '');
    if (empty($site_key)) {
        return;
    }

    // Check if we're on a CF7 page
    $allowed_pages = wpcc_get_cf7_allowed_pages();
    $is_cf7_page = false;

    if (is_page($allowed_pages) || is_single($allowed_pages)) {
        $is_cf7_page = true;
    }

    global $post;
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'contact-form-7')) {
        $is_cf7_page = true;
    }

    if (!$is_cf7_page) {
        return;
    }

    // Enqueue reCAPTCHA v3 script
    wp_enqueue_script(
        'wpcc-recaptcha-v3',
        'https://www.google.com/recaptcha/api.js?render=' . $site_key,
        array(),
        null,
        true
    );

    // Add inline script to execute reCAPTCHA on form submission
    $inline_script = "
    document.addEventListener('DOMContentLoaded', function() {
        const forms = document.querySelectorAll('.wpcf7-form');
        forms.forEach(function(form) {
            form.addEventListener('submit', function(e) {
                // Check if reCAPTCHA token already exists
                let tokenField = form.querySelector('input[name=\"wpcc-recaptcha-token\"]');
                if (tokenField && tokenField.value) {
                    // Token already exists, allow submission
                    return;
                }

                // Prevent submission until we get the token
                e.preventDefault();
                e.stopImmediatePropagation();

                grecaptcha.ready(function() {
                    grecaptcha.execute('{$site_key}', {action: 'contact_form'}).then(function(token) {
                        // Create hidden field if doesn't exist
                        if (!tokenField) {
                            tokenField = document.createElement('input');
                            tokenField.type = 'hidden';
                            tokenField.name = 'wpcc-recaptcha-token';
                            form.appendChild(tokenField);
                        }
                        tokenField.value = token;

                        // Submit the form
                        form.submit();
                    });
                });
            });
        });
    });
    ";
    wp_add_inline_script('wpcc-recaptcha-v3', $inline_script);
}

// Validate reCAPTCHA token on CF7 submission
add_filter('wpcf7_validate', 'wpcc_verify_recaptcha', 10, 2);
function wpcc_verify_recaptcha($result, $tags) {
    // Only run if reCAPTCHA is enabled
    if (!get_option('wpcc_recaptcha_enabled', false)) {
        return $result;
    }

    $secret_key = get_option('wpcc_recaptcha_secret_key', '');
    if (empty($secret_key)) {
        return $result;
    }

    // Get the token from POST data
    $token = isset($_POST['wpcc-recaptcha-token']) ? sanitize_text_field($_POST['wpcc-recaptcha-token']) : '';

    if (empty($token)) {
        $result->invalidate('wpcc-recaptcha', 'reCAPTCHA verification failed. Please try again.');
        return $result;
    }

    // Verify token with Google
    $response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', array(
        'body' => array(
            'secret' => $secret_key,
            'response' => $token,
            'remoteip' => $_SERVER['REMOTE_ADDR']
        )
    ));

    if (is_wp_error($response)) {
        $result->invalidate('wpcc-recaptcha', 'reCAPTCHA verification request failed.');
        return $result;
    }

    $response_body = wp_remote_retrieve_body($response);
    $data = json_decode($response_body);

    if (!$data->success) {
        $result->invalidate('wpcc-recaptcha', 'reCAPTCHA verification failed. Please try again.');
        return $result;
    }

    // Check score threshold (v3 gives a score from 0.0 to 1.0)
    $threshold = floatval(get_option('wpcc_recaptcha_threshold', '0.5'));
    if (isset($data->score) && $data->score < $threshold) {
        $result->invalidate('wpcc-recaptcha', 'reCAPTCHA score too low. Please try again.');
        return $result;
    }

    return $result;
}

// ============================================
// COOKIE CONSENT FEATURES
// ============================================

// Output banner styles in head
add_action('wp_head', 'wpcc_output_styles', 100);
function wpcc_output_styles() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }
    echo '<style id="wpcc-banner-styles">' . wpcc_get_banner_styles() . '</style>';
}

// Output consent script in footer
add_action('wp_footer', 'wpcc_output_script', 20);
function wpcc_output_script() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }
    echo '<script id="wpcc-consent-script">' . wpcc_get_consent_script() . '</script>';
}

// Add Consent Mode v2 script to <head> (must be first)
add_action('wp_head', 'wpcc_render_consent_mode', 1);
function wpcc_render_consent_mode() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }

    $ga4_id = get_option('wpcc_ga4_id', '');
    if (empty($ga4_id)) {
        return;
    }
    ?>
    <!-- Google Consent Mode v2 -->
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('consent', 'default', {
        'analytics_storage': 'denied',
        'ad_storage': 'denied',
        'functionality_storage': 'denied',
        'personalization_storage': 'denied',
        'wait_for_update': 500
    });
    gtag('js', new Date());
    </script>
    <?php
}

// Render consent UI (banner or footer strip based on geolocation)
add_action('wp_footer', 'wpcc_render_consent_ui', 5);
function wpcc_render_consent_ui() {
    if (!get_option('wpcc_enabled', true)) {
        echo '<!-- WPCC: Plugin disabled -->';
        return;
    }

    $mode = wpcc_get_consent_mode();
    $disable_gdpr = get_option('wpcc_disable_gdpr_banner', false);
    echo '<!-- WPCC: Consent mode is: ' . esc_html($mode) . ' -->';

    if ($mode === 'footer') {
        echo '<!-- WPCC: Calling wpcc_render_footer_strip() -->';
        wpcc_render_footer_strip();
        echo '<!-- WPCC: Footer strip render completed -->';
    } else if ($mode === 'banner' && !$disable_gdpr) {
        echo '<!-- WPCC: Calling wpcc_render_gdpr_banner() -->';
        wpcc_render_gdpr_banner();
    } else {
        echo '<!-- WPCC: GDPR banner disabled for this visitor -->';
    }

    // Always output config for JavaScript
    $ga4_id = get_option('wpcc_ga4_id', '');
    $gtm_id = get_option('wpcc_gtm_id', '');
    $expiry_days = get_option('wpcc_consent_expiry_days', 180);
    ?>
    <script>
    // Pass PHP variables to JavaScript
    window.wpccConfig = {
        ga4Id: '<?php echo esc_js($ga4_id); ?>',
        gtmId: '<?php echo esc_js($gtm_id); ?>',
        expiryDays: <?php echo absint($expiry_days); ?>,
        mode: '<?php echo esc_js($mode); ?>'
    };
    </script>
    <?php
}

// Render GDPR pill banner (for EU/GDPR countries)
function wpcc_render_gdpr_banner() {
    $title = get_option('wpcc_banner_title', 'We use cookies');
    $body = get_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.');
    $accept_label = get_option('wpcc_accept_label', 'Accept');
    $reject_label = get_option('wpcc_reject_label', 'Reject');
    $learn_more_url = get_option('wpcc_learn_more_url', '/privacy-policy#cookies');
    ?>
    <div id="wpcc-banner" class="wpcc-banner" role="dialog" aria-modal="false" aria-live="polite" aria-label="Cookie consent" style="display:none;">
        <span class="wpcc-banner__text">
            <?php echo wp_kses_post($body); ?> <a href="<?php echo esc_url($learn_more_url); ?>" class="wpcc-banner__link">Learn more</a>
        </span>
        <div class="wpcc-banner__actions">
            <button id="wpcc-reject" class="wpcc-btn wpcc-btn--secondary" type="button" aria-label="<?php echo esc_attr($reject_label); ?>">
                <?php echo esc_html($reject_label); ?>
            </button>
            <button id="wpcc-accept" class="wpcc-btn wpcc-btn--primary" type="button" aria-label="<?php echo esc_attr($accept_label); ?>">
                <?php echo esc_html($accept_label); ?>
            </button>
        </div>
    </div>
    <?php
}

// Render footer strip (for USA/CCPA compliance)
function wpcc_render_footer_strip() {
    // Debug: Log that this function is being called
    error_log('[WPCC] wpcc_render_footer_strip() called');

    $style = get_option('wpcc_footer_style', 'a');
    if (empty($style)) {
        $style = 'a'; // Default to 'a' if empty
    }
    error_log('[WPCC] Footer style value: ' . var_export($style, true));

    // Get copyright text with token support
    $copyright_text = get_option('wpcc_footer_copyright_text', '© {year} {site_name} | Powered by <a href="https://marketingaid.com" target="_blank" rel="noopener noreferrer">MarketingAid</a>');

    // Replace tokens
    $copyright_text = str_replace('{year}', date('Y'), $copyright_text);
    $copyright_text = str_replace('{site_name}', get_bloginfo('name'), $copyright_text);

    $show_terms = get_option('wpcc_footer_show_terms', true);
    $terms_label = get_option('wpcc_footer_terms_label', 'Terms of Service');
    $terms_url = get_option('wpcc_footer_terms_url', '/terms-of-service');
    $show_privacy = get_option('wpcc_footer_show_privacy', true);
    $privacy_label = get_option('wpcc_footer_privacy_label', 'Privacy Policy');
    $privacy_url = get_option('wpcc_footer_privacy_url', '/privacy-policy');
    $show_cookies = get_option('wpcc_footer_show_cookies', true);
    $cookies_label = get_option('wpcc_footer_cookies_label', 'Cookie Policy');
    $cookies_url = get_option('wpcc_footer_cookies_url', '/cookie-policy');

    // Official CCPA opt-out icon SVG
    $ccpa_icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 14" role="img" aria-label="Your Privacy Choices opt-out icon"><style>.i0{fill-rule:evenodd;clip-rule:evenodd;fill:#FFFFFF}.i1{fill-rule:evenodd;clip-rule:evenodd;fill:#0066FF}.i2{fill:#FFFFFF}.i3{fill:#0066FF}</style><path class="i0" d="M7.4,12.8h6.8l3.1-11.6H7.4C4.2,1.2,1.6,3.8,1.6,7S4.2,12.8,7.4,12.8z"/><path class="i1" d="M22.6,0H7.4c-3.9,0-7,3.1-7,7s3.1,7,7,7h15.2c3.9,0,7-3.1,7-7S26.4,0,22.6,0zM1.6,7c0-3.2,2.6-5.8,5.8-5.8h9.9l-3.1,11.6H7.4C4.2,12.8,1.6,10.2,1.6,7z"/><path class="i2" d="M24.6,4c0.2,0.2,0.2,0.6,0,0.8L22.5,7l2.2,2.2c0.2,0.2,0.2,0.6,0,0.8c-0.2,0.2-0.6,0.2-0.8,0l-2.2-2.2L19.5,10c-0.2,0.2-0.6,0.2-0.8,0c-0.2-0.2-0.2-0.6,0-0.8L20.8,7l-2.2-2.2c-0.2-0.2-0.2-0.6,0-0.8c0.2-0.2,0.6-0.2,0.8,0l2.2,2.2L23.8,4C24,3.8,24.4,3.8,24.6,4z"/><path class="i3" d="M12.7,4.1c0.2,0.2,0.3,0.6,0.1,0.8L8.6,9.8C8.5,9.9,8.4,10,8.3,10c-0.2,0.1-0.5,0.1-0.7-0.1L5.4,7.7c-0.2-0.2-0.2-0.6,0-0.8c0.2-0.2,0.6-0.2,0.8,0L8,8.6l3.8-4.5C12,3.9,12.4,3.9,12.7,4.1z"/></svg>';

    // Render based on selected style
    error_log('[WPCC] Checking style condition: $style = ' . var_export($style, true));
    if ($style === 'a'):
        error_log('[WPCC] Style condition TRUE - rendering footer HTML');
        ?>
        <!-- WPCC Footer Strip Start -->
        <div class="wpcc-footer-strip wpcc-footer-a">
            <span class="wpcc-footer-copy">
                <?php echo wp_kses_post($copyright_text); ?>
            </span>
            <div class="wpcc-footer-links">
                <?php if ($show_terms): ?>
                    <a class="wpcc-ls-link" href="<?php echo esc_url($terms_url); ?>"><?php echo esc_html($terms_label); ?></a>
                    <div class="wpcc-divider"></div>
                <?php endif; ?>
                <?php if ($show_privacy): ?>
                    <a class="wpcc-ls-link" href="<?php echo esc_url($privacy_url); ?>"><?php echo esc_html($privacy_label); ?></a>
                    <div class="wpcc-divider"></div>
                <?php endif; ?>
                <?php if ($show_cookies): ?>
                    <a class="wpcc-ls-link" href="<?php echo esc_url($cookies_url); ?>"><?php echo esc_html($cookies_label); ?></a>
                    <div class="wpcc-divider"></div>
                <?php endif; ?>
                <span class="wpcc-privacy-icon" id="wpcc-privacy-choices" style="cursor:pointer;">
                    <span class="wpcc-ccpa-icon"><?php echo $ccpa_icon; ?></span>
                    Your Privacy Choices
                </span>
            </div>
        </div>

        <!-- Privacy Choices Modal -->
        <div class="wpcc-modal-overlay" id="wpcc-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="wpcc-modal-title">
            <div class="wpcc-modal">
                <div class="wpcc-modal-header">
                    <div class="wpcc-modal-header-left">
                        <div class="wpcc-modal-eyebrow">
                            <span class="wpcc-ccpa-icon"><?php echo $ccpa_icon; ?></span>
                            <span class="wpcc-modal-eyebrow-text">California Privacy Rights · CCPA</span>
                        </div>
                        <h2 class="wpcc-modal-title" id="wpcc-modal-title">Your Privacy Choices</h2>
                    </div>
                    <button class="wpcc-modal-close" id="wpcc-modal-close" aria-label="Close privacy choices">✕</button>
                </div>

                <p class="wpcc-modal-intro">
                    Control how your data is used on this site. Changes apply to this browser only.
                    For full details see our <a href="<?php echo esc_url($privacy_url); ?>" target="_blank">Privacy Policy</a>.
                </p>

                <div class="wpcc-modal-divider"></div>

                <div class="wpcc-consent-rows">
                    <div class="wpcc-consent-row">
                        <div class="wpcc-consent-info">
                            <div class="wpcc-consent-name">
                                Strictly Necessary
                                <span class="wpcc-consent-badge wpcc-badge-required">Always on</span>
                            </div>
                            <div class="wpcc-consent-vendor">Cloudflare · Session cookies</div>
                            <div class="wpcc-consent-desc">Required for the site to function — security, load balancing, and session management. Cannot be disabled.</div>
                        </div>
                        <div class="wpcc-consent-control">
                            <label class="wpcc-toggle" aria-label="Strictly necessary cookies — always on">
                                <input type="checkbox" checked disabled>
                                <div class="wpcc-toggle-track"></div>
                                <div class="wpcc-toggle-thumb"></div>
                            </label>
                            <div class="wpcc-toggle-state wpcc-on">On</div>
                        </div>
                    </div>

                    <div class="wpcc-consent-row">
                        <div class="wpcc-consent-info">
                            <div class="wpcc-consent-name">
                                Analytics
                                <span class="wpcc-consent-badge wpcc-badge-optional">Optional</span>
                            </div>
                            <div class="wpcc-consent-vendor">Google Analytics 4 · Up to 180 days</div>
                            <div class="wpcc-consent-desc">Helps us understand how visitors use our site — pages visited, time on site, referral source. Your data is never sold to third parties.</div>
                        </div>
                        <div class="wpcc-consent-control">
                            <label class="wpcc-toggle" aria-label="Analytics cookies toggle">
                                <input type="checkbox" id="wpcc-toggle-analytics">
                                <div class="wpcc-toggle-track"></div>
                                <div class="wpcc-toggle-thumb"></div>
                            </label>
                            <div class="wpcc-toggle-state" id="wpcc-state-analytics">Off</div>
                        </div>
                    </div>
                </div>

                <div class="wpcc-modal-footer">
                    <div class="wpcc-modal-actions">
                        <button class="wpcc-modal-btn wpcc-modal-btn-reject" id="wpcc-modal-reject">Reject All</button>
                        <button class="wpcc-modal-btn wpcc-modal-btn-save" id="wpcc-modal-save">Save My Choices</button>
                    </div>
                    <p class="wpcc-modal-legal">
                        Applies to this browser only. To reset, clear your cookies or return to this modal.
                    </p>
                </div>
            </div>
        </div>

        <!-- Toast notification -->
        <div class="wpcc-toast" id="wpcc-toast"></div>
    <?php endif;
}

// Get banner CSS
function wpcc_get_banner_styles() {
    $banner_bg = get_option('wpcc_banner_bg_color', '#ffffff');
    $banner_text = get_option('wpcc_banner_text_color', '#111111');
    $accept_bg = get_option('wpcc_accept_bg_color', '#111111');
    $accept_text = get_option('wpcc_accept_text_color', '#ffffff');
    $reject_border = get_option('wpcc_reject_border_color', '#111111');

    return '
    /* ── Pill container ── */
    .wpcc-banner {
        position: fixed;
        bottom: 1.5rem;
        left: 50%;
        transform: translateX(-50%);
        z-index: 999999;
        max-width: calc(100% - 2rem);

        display: flex;
        align-items: center;
        gap: 0.75rem;
        flex-wrap: nowrap;
        white-space: nowrap;

        padding: 0.5rem 0.65rem 0.5rem 1rem;
        border-radius: 100px;

        background: ' . esc_attr($banner_bg) . ';
        color: ' . esc_attr($banner_text) . ';
        border: 1px solid rgba(0,0,0,0.10);
        box-shadow: 0 4px 24px rgba(0,0,0,0.10), 0 1px 4px rgba(0,0,0,0.06);

        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);

        font-size: 0.8rem;
        line-height: 1.4;
    }

    /* ── Inline text + link ── */
    .wpcc-banner__text {
        color: ' . esc_attr($banner_text) . ';
        opacity: 0.72;
    }

    .wpcc-banner__link {
        color: ' . esc_attr($banner_text) . ';
        opacity: 1;
        text-decoration: underline;
        text-underline-offset: 2px;
        text-decoration-thickness: 1px;
        margin-left: 0.15rem;
    }

    .wpcc-banner__link:hover {
        opacity: 0.7;
    }

    /* ── Button row ── */
    .wpcc-banner__actions {
        display: flex;
        gap: 0.35rem;
        flex-shrink: 0;
    }

    /* ── Shared button base ── */
    .wpcc-btn {
        font-size: 0.75rem;
        font-weight: 500;
        letter-spacing: 0.03em;
        padding: 0.45rem 1rem;
        border-radius: 100px;
        border: 1px solid transparent;
        cursor: pointer;
        white-space: nowrap;
        min-height: 0;
        min-width: 0;
        transition: opacity 0.15s ease, transform 0.1s ease;
        line-height: 1;
        font-family: inherit;
    }

    .wpcc-btn:active {
        transform: scale(0.97);
    }

    /* ── Accept (filled) ── */
    .wpcc-btn--primary {
        background: ' . esc_attr($accept_bg) . ';
        color: ' . esc_attr($accept_text) . ';
        border-color: ' . esc_attr($accept_bg) . ';
    }

    .wpcc-btn--primary:hover {
        opacity: 0.85;
    }

    .wpcc-btn--primary:focus-visible {
        outline: 2px solid #005FCC;
        outline-offset: 2px;
    }

    /* ── Reject (outline — same visual weight as accept) ── */
    .wpcc-btn--secondary {
        background: transparent;
        color: ' . esc_attr($banner_text) . ';
        border-color: ' . esc_attr($reject_border) . ';
        opacity: 0.65;
    }

    .wpcc-btn--secondary:hover {
        opacity: 1;
    }

    .wpcc-btn--secondary:focus-visible {
        outline: 2px solid #005FCC;
        outline-offset: 2px;
    }

    /* ── Tablet: allow wrapping but keep pill shape ── */
    @media (max-width: 768px) {
        .wpcc-banner {
            max-width: calc(100% - 1.5rem);
            white-space: normal;
            flex-wrap: wrap;
            padding: 0.65rem 0.75rem 0.65rem 1rem;
            gap: 0.6rem;
        }

        .wpcc-banner__text {
            flex: 1 1 auto;
            min-width: 200px;
        }

        .wpcc-banner__actions {
            gap: 0.4rem;
        }

        .wpcc-btn {
            padding: 0.5rem 1rem;
            font-size: 0.75rem;
        }
    }

    /* ── Mobile: full-width bottom bar ── */
    @media (max-width: 600px) {
        .wpcc-banner {
            bottom: 0;
            left: 0;
            right: 0;
            max-width: none;
            transform: none;
            border-radius: 0;
            border-top: 1px solid rgba(0,0,0,0.08);
            border-left: none;
            border-right: none;
            border-bottom: none;
            box-shadow: 0 -2px 12px rgba(0,0,0,0.08);
            padding: 0.85rem 1rem;
            gap: 0.65rem;
        }

        .wpcc-banner__text {
            flex: 1 1 100%;
            min-width: 0;
        }

        .wpcc-banner__actions {
            width: 100%;
            gap: 0.5rem;
        }

        .wpcc-btn {
            flex: 1;
            padding: 0.6rem 1rem;
            font-size: 0.8rem;
            border-radius: 6px;
            text-align: center;
        }
    }

    /* ══════════════════════════════════════════════
       FOOTER STRIP (USA/CCPA)
       ══════════════════════════════════════════════ */

    /* Shared link styles */
    .wpcc-ls-link {
        font-size: 0.7rem;
        letter-spacing: 0.03em;
        text-decoration: none;
        white-space: nowrap;
        transition: opacity 0.15s;
        cursor: pointer;
    }
    .wpcc-ls-link:hover { opacity: 0.6; }

    .wpcc-privacy-icon {
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        font-size: 0.7rem;
        white-space: nowrap;
        transition: opacity 0.15s;
    }
    .wpcc-privacy-icon:hover { opacity: 0.7; }

    /* CCPA icon */
    .wpcc-ccpa-icon {
        display: inline-flex;
        align-items: center;
        flex-shrink: 0;
        line-height: 1;
    }
    .wpcc-ccpa-icon svg {
        height: 14px;
        width: auto;
        vertical-align: middle;
    }

    /* Variant A: Dark minimal single line */
    .wpcc-footer-a {
        position: relative;
        width: 100%;
        margin: 0;
        background: ' . esc_attr(get_option('wpcc_footer_bg_color', '#0d0b08')) . ';
        color: ' . esc_attr(get_option('wpcc_footer_text_color', 'rgba(255,255,255,0.38)')) . ';
        padding: 0 2rem;
        height: 38px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        border-top: 1px solid rgba(255,255,255,0.05);
        flex-wrap: nowrap;
        overflow: hidden;
        box-sizing: border-box;
    }

    .wpcc-footer-copy {
        font-size: 0.65rem;
        letter-spacing: 0.04em;
        flex-shrink: 0;
        color: ' . esc_attr(get_option('wpcc_footer_copyright_color', 'rgba(255,255,255,0.6)')) . ';
    }

    .wpcc-marketingaid-link {
        color: ' . esc_attr(get_option('wpcc_footer_link_color', 'rgba(255,255,255,0.6)')) . ';
        text-decoration: none;
        transition: color 0.2s ease, opacity 0.2s ease;
    }

    .wpcc-marketingaid-link:hover {
        opacity: 0.8;
    }

    .wpcc-footer-links {
        display: flex;
        align-items: center;
        gap: 1.5rem;
        flex-wrap: nowrap;
    }

    .wpcc-footer-a .wpcc-ls-link {
        color: ' . esc_attr(get_option('wpcc_footer_link_color', 'rgba(255,255,255,0.6)')) . ';
    }

    .wpcc-footer-a .wpcc-privacy-icon {
        color: ' . esc_attr(get_option('wpcc_footer_link_color', 'rgba(255,255,255,0.6)')) . ';
    }

    .wpcc-divider {
        width: 1px;
        height: 10px;
        background: rgba(255,255,255,0.12);
        flex-shrink: 0;
    }

    /* Mobile responsive */
    @media (max-width: 768px) {
        .wpcc-footer-a {
            height: auto;
            flex-direction: column;
            align-items: flex-start;
            padding: 0.85rem 1.5rem;
            gap: 0.6rem;
        }

        .wpcc-footer-copy {
            order: 2;
            width: 100%;
        }

        .wpcc-footer-links {
            order: 1;
            width: 100%;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .wpcc-divider {
            display: none;
        }
    }

    /* ══════════════════════════════════════════════
       PRIVACY CHOICES MODAL
       ══════════════════════════════════════════════ */
    .wpcc-modal-overlay {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.85);
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(6px);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 1.5rem;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.28s ease;
    }
    .wpcc-modal-overlay.wpcc-open {
        opacity: 1;
        pointer-events: auto;
    }

    .wpcc-modal {
        background: #111111;
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 16px;
        width: 100%;
        max-width: 480px;
        box-shadow: 0 32px 80px rgba(0,0,0,0.8), 0 2px 8px rgba(0,0,0,0.5);
        transform: translateY(16px) scale(0.98);
        transition: transform 0.35s cubic-bezier(0.22, 1, 0.36, 1);
        overflow: hidden;
    }
    .wpcc-modal-overlay.wpcc-open .wpcc-modal {
        transform: translateY(0) scale(1);
    }

    .wpcc-modal-header {
        padding: 1.5rem 1.5rem 0;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1rem;
    }
    .wpcc-modal-header-left {
        display: flex;
        flex-direction: column;
        gap: 0.4rem;
    }
    .wpcc-modal-eyebrow {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .wpcc-modal-eyebrow-text {
        font-size: 0.6rem;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        color: #666666;
        font-weight: 500;
    }
    .wpcc-modal-title {
        font-size: 1.35rem;
        font-weight: 400;
        color: #f5f5f5;
        line-height: 1.2;
        letter-spacing: 0.01em;
    }
    .wpcc-modal-close {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 50%;
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: rgba(255,255,255,0.4);
        font-size: 0.9rem;
        flex-shrink: 0;
        margin-top: 2px;
        transition: background 0.15s, color 0.15s;
        line-height: 1;
    }
    .wpcc-modal-close:hover {
        background: rgba(255,255,255,0.1);
        color: rgba(255,255,255,0.8);
    }

    .wpcc-modal-intro {
        padding: 0.75rem 1.5rem 0;
        font-size: 0.73rem;
        color: #999999;
        line-height: 1.65;
    }
    .wpcc-modal-intro a {
        color: #cccccc;
        text-decoration: underline;
        text-underline-offset: 2px;
        text-decoration-thickness: 1px;
    }

    .wpcc-modal-divider {
        height: 1px;
        background: rgba(255,255,255,0.08);
        margin: 1.25rem 1.5rem 0;
    }

    .wpcc-consent-rows {
        padding: 0 1.5rem;
    }

    .wpcc-consent-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1.25rem;
        padding: 1rem 0;
        border-bottom: 1px solid rgba(255,255,255,0.05);
    }
    .wpcc-consent-row:last-child {
        border-bottom: none;
    }

    .wpcc-consent-info {
        flex: 1;
        min-width: 0;
    }

    .wpcc-consent-name {
        font-size: 0.8rem;
        font-weight: 500;
        color: #e5e5e5;
        margin-bottom: 0.25rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .wpcc-consent-badge {
        font-size: 0.55rem;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        padding: 0.15rem 0.45rem;
        border-radius: 3px;
        font-weight: 500;
    }
    .wpcc-badge-required {
        background: rgba(74,158,107,0.15);
        color: #6bc397;
        border: 1px solid rgba(74,158,107,0.25);
    }
    .wpcc-badge-optional {
        background: rgba(255,255,255,0.08);
        color: #999999;
        border: 1px solid rgba(255,255,255,0.12);
    }

    .wpcc-consent-vendor {
        font-size: 0.65rem;
        color: #666666;
        margin-bottom: 0.3rem;
        letter-spacing: 0.02em;
    }
    .wpcc-consent-desc {
        font-size: 0.7rem;
        color: #888888;
        line-height: 1.55;
    }

    .wpcc-consent-control {
        flex-shrink: 0;
        padding-top: 2px;
    }

    .wpcc-toggle {
        position: relative;
        width: 42px;
        height: 24px;
        display: block;
    }
    .wpcc-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
        position: absolute;
    }
    .wpcc-toggle-track {
        position: absolute;
        inset: 0;
        background: #222222;
        border: 1px solid rgba(255,255,255,0.12);
        border-radius: 12px;
        cursor: pointer;
        transition: background 0.22s, border-color 0.22s;
    }
    .wpcc-toggle input:checked + .wpcc-toggle-track {
        background: #ffffff;
        border-color: #ffffff;
    }
    .wpcc-toggle input:disabled + .wpcc-toggle-track {
        cursor: not-allowed;
        opacity: 0.5;
    }
    .wpcc-toggle-thumb {
        position: absolute;
        top: 3px;
        left: 3px;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: #666666;
        box-shadow: 0 1px 3px rgba(0,0,0,0.5);
        transition: transform 0.22s cubic-bezier(0.22, 1, 0.36, 1), background 0.22s;
        pointer-events: none;
    }
    .wpcc-toggle input:checked ~ .wpcc-toggle-thumb {
        transform: translateX(18px);
        background: #111111;
    }

    .wpcc-toggle-state {
        font-size: 0.58rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #444444;
        margin-top: 5px;
        text-align: center;
        transition: color 0.2s;
        font-weight: 500;
    }
    .wpcc-toggle-state.wpcc-on {
        color: #999999;
    }

    .wpcc-modal-footer {
        padding: 1.25rem 1.5rem 1.5rem;
        background: rgba(0,0,0,0.3);
        border-top: 1px solid rgba(255,255,255,0.05);
        display: flex;
        flex-direction: column;
        gap: 0.85rem;
    }

    .wpcc-modal-actions {
        display: flex;
        gap: 0.6rem;
    }

    .wpcc-modal-btn {
        flex: 1;
        font-size: 0.73rem;
        font-weight: 400;
        letter-spacing: 0.04em;
        padding: 0.65rem 1rem;
        border-radius: 8px;
        cursor: pointer;
        transition: opacity 0.15s, transform 0.1s;
        border: 1px solid transparent;
        line-height: 1;
        font-family: inherit;
    }
    .wpcc-modal-btn:active {
        transform: scale(0.98);
    }

    .wpcc-modal-btn-reject {
        background: transparent;
        color: #888888;
        border-color: rgba(255,255,255,0.12);
    }
    .wpcc-modal-btn-reject:hover {
        color: #cccccc;
        border-color: rgba(255,255,255,0.2);
    }

    .wpcc-modal-btn-save {
        background: #ffffff;
        color: #111111;
        border-color: #ffffff;
        font-weight: 500;
    }
    .wpcc-modal-btn-save:hover {
        opacity: 0.9;
    }

    .wpcc-modal-legal {
        font-size: 0.62rem;
        color: #555555;
        line-height: 1.6;
        text-align: center;
    }
    .wpcc-modal-legal a {
        color: #777777;
        text-decoration: underline;
        text-underline-offset: 2px;
    }

    .wpcc-toast {
        position: fixed;
        bottom: 2rem;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: #1a1a1a;
        border: 1px solid rgba(255,255,255,0.15);
        color: #e5e5e5;
        font-size: 0.72rem;
        padding: 0.6rem 1.2rem;
        border-radius: 100px;
        letter-spacing: 0.04em;
        opacity: 0;
        transition: opacity 0.25s, transform 0.25s;
        pointer-events: none;
        white-space: nowrap;
        z-index: 999999;
    }
    .wpcc-toast.wpcc-show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }

    /* reCAPTCHA badge positioning */
    .grecaptcha-badge {
        bottom: 60px !important;
        z-index: 999998 !important;
    }
    ';
}

// Get consent JavaScript
function wpcc_get_consent_script() {
    return "
    (function() {
        'use strict';

        const CONSENT_KEY = 'wpcc_consent';
        const banner = document.getElementById('wpcc-banner');
        const acceptBtn = document.getElementById('wpcc-accept');
        const rejectBtn = document.getElementById('wpcc-reject');
        const config = window.wpccConfig || {};

        // Check if consent exists and is valid
        function hasValidConsent() {
            try {
                const stored = localStorage.getItem(CONSENT_KEY);
                if (!stored) {
                    console.log('[WPCC] No stored consent found');
                    return null;
                }

                const data = JSON.parse(stored);
                const now = Date.now();

                if (now > data.expires) {
                    console.log('[WPCC] Stored consent expired');
                    localStorage.removeItem(CONSENT_KEY);
                    return null;
                }

                console.log('[WPCC] Valid consent found:', data.value);
                return data.value; // 'accepted' or 'rejected'
            } catch (e) {
                console.error('[WPCC] Error reading consent:', e);
                return null;
            }
        }

        // Save consent decision
        function saveConsent(value) {
            const expiryMs = (config.expiryDays || 180) * 24 * 60 * 60 * 1000;
            const data = {
                value: value,
                expires: Date.now() + expiryMs
            };
            localStorage.setItem(CONSENT_KEY, JSON.stringify(data));
            console.log('[WPCC] Consent saved:', value, '(expires in ' + config.expiryDays + ' days)');
        }

        // Load GTM (Google Tag Manager)
        function loadGTM() {
            if (!config.gtmId) {
                console.log('[WPCC] No GTM ID configured - skipping GTM load');
                return;
            }

            // Check if already loaded
            if (window.google_tag_manager && window.google_tag_manager[config.gtmId]) {
                console.log('[WPCC] GTM already loaded');
                return;
            }

            console.log('[WPCC] Loading Google Tag Manager with ID:', config.gtmId);

            // GTM script injection
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer',config.gtmId);

            // Update consent mode for GTM
            if (typeof gtag === 'function') {
                gtag('consent', 'update', {
                    'analytics_storage': 'granted',
                    'ad_storage': 'denied',
                    'functionality_storage': 'granted',
                    'personalization_storage': 'denied'
                });
                console.log('[WPCC] GTM consent updated to GRANTED (analytics only)');
            }
        }

        // Load GA4 tracking
        function loadGA4() {
            if (!config.ga4Id) {
                console.log('[WPCC] No GA4 ID configured - skipping GA4 load');
                return;
            }

            // Check if already loaded
            if (document.querySelector('script[src*=\"' + config.ga4Id + '\"]')) {
                console.log('[WPCC] GA4 already loaded');
                return;
            }

            console.log('[WPCC] Loading GA4 tracking with ID:', config.ga4Id);

            // Create and append GA4 script
            const script = document.createElement('script');
            script.async = true;
            script.src = 'https://www.googletagmanager.com/gtag/js?id=' + config.ga4Id;
            document.head.appendChild(script);

            // Update consent mode
            if (typeof gtag === 'function') {
                gtag('consent', 'update', {
                    'analytics_storage': 'granted'
                });
                gtag('config', config.ga4Id);
                console.log('[WPCC] GA4 consent updated to GRANTED');
            } else {
                console.warn('[WPCC] gtag function not available yet - consent will update when GA4 loads');
            }
        }

        // Load all tracking (GTM + GA4)
        function loadTracking() {
            loadGTM();
            loadGA4();
        }

        // Show banner
        function showBanner() {
            if (banner) {
                console.log('[WPCC] Showing cookie consent banner');
                banner.style.display = 'block';
                // Focus on first button (reject) for accessibility
                setTimeout(function() {
                    if (rejectBtn) rejectBtn.focus();
                }, 100);
            }
        }

        // Hide banner
        function hideBanner() {
            if (banner) {
                console.log('[WPCC] Hiding banner');
                banner.style.display = 'none';
            }
        }

        // Handle accept
        function handleAccept() {
            console.log('[WPCC] User clicked ACCEPT');
            saveConsent('accepted');
            loadTracking();
            hideBanner();
        }

        // Handle reject
        function handleReject() {
            console.log('[WPCC] User clicked REJECT - GA4 will NOT be loaded');
            saveConsent('rejected');
            hideBanner();
        }

        // Initialize
        function init() {
            console.log('[WPCC] Initializing cookie consent system (mode: ' + config.mode + ')');
            const consent = hasValidConsent();

            // GDPR/Banner mode: show banner if no consent
            if (config.mode === 'banner') {
                if (consent === 'accepted') {
                    console.log('[WPCC] Previous consent: ACCEPTED - loading GA4');
                    loadTracking();
                } else if (consent === null) {
                    console.log('[WPCC] No previous consent - showing banner');
                    showBanner();
                } else {
                    console.log('[WPCC] Previous consent: REJECTED - GA4 will not load');
                }
            }
            // Footer mode (USA/CCPA): opt-out model, analytics ON by default unless explicitly rejected
            else if (config.mode === 'footer') {
                if (consent === 'rejected') {
                    console.log('[WPCC] Footer mode: User has REJECTED tracking - analytics OFF');
                } else {
                    // Load tracking if accepted OR if no prior consent (opt-out model)
                    if (consent === 'accepted') {
                        console.log('[WPCC] Footer mode: User has ACCEPTED tracking - loading analytics');
                    } else {
                        console.log('[WPCC] Footer mode: No prior consent - loading analytics by default (opt-out model)');
                    }
                    loadTracking();
                }

                // Modal functions (make them global for event handlers)
                window.wpccOpenModal = function() {
                    const overlay = document.getElementById('wpcc-modal-overlay');
                    const toggle = document.getElementById('wpcc-toggle-analytics');

                    if (!overlay || !toggle) {
                        console.error('[WPCC] Modal elements not found in DOM');
                        return;
                    }

                    // Set toggle state from current consent
                    const currentConsent = hasValidConsent();
                    if (currentConsent === 'accepted') {
                        toggle.checked = true;
                        wpccUpdateToggleState(toggle, true);
                    } else if (currentConsent === 'rejected') {
                        toggle.checked = false;
                        wpccUpdateToggleState(toggle, false);
                    } else {
                        // No prior consent (CCPA mode for USA visitors)
                        // Default to ON - analytics enabled by default (opt-out model)
                        toggle.checked = true;
                        wpccUpdateToggleState(toggle, true);
                    }

                    overlay.classList.add('wpcc-open');

                    // Focus first interactive element
                    setTimeout(function() {
                        toggle.focus();
                    }, 350);
                }

                window.wpccCloseModal = function() {
                    const overlay = document.getElementById('wpcc-modal-overlay');
                    if (overlay) {
                        overlay.classList.remove('wpcc-open');
                    }
                };

                window.wpccUpdateToggleState = function(input, checked) {
                    const stateEl = document.getElementById('wpcc-state-analytics');
                    if (stateEl) {
                        stateEl.textContent = checked ? 'On' : 'Off';
                        if (checked) {
                            stateEl.classList.add('wpcc-on');
                        } else {
                            stateEl.classList.remove('wpcc-on');
                        }
                    }
                }

                window.wpccShowToast = function(msg) {
                    const toast = document.getElementById('wpcc-toast');
                    if (toast) {
                        toast.textContent = msg;
                        toast.classList.add('wpcc-show');
                        setTimeout(function() {
                            toast.classList.remove('wpcc-show');
                        }, 2800);
                    }
                }

                window.wpccModalReject = function() {
                    saveConsent('rejected');
                    wpccCloseModal();
                    wpccShowToast('Preferences saved — analytics off');
                }

                window.wpccModalSave = function() {
                    const analytics = document.getElementById('wpcc-toggle-analytics').checked;
                    const previousConsent = hasValidConsent();

                    if (analytics) {
                        saveConsent('accepted');
                        loadTracking();
                        wpccShowToast('Preferences saved — analytics on');
                        wpccCloseModal();
                    } else {
                        saveConsent('rejected');

                        // If user is withdrawing consent (was null/accepted, now rejected), reload page
                        // to ensure tracking scripts don't continue running
                        if (previousConsent !== 'rejected') {
                            wpccShowToast('Preferences saved — reloading page to stop tracking...');
                            setTimeout(function() {
                                window.location.reload();
                            }, 1000);
                        } else {
                            wpccShowToast('Preferences saved — analytics off');
                            wpccCloseModal();
                        }
                    }
                }

                // Attach modal events with logging
                console.log('[WPCC] Attaching footer modal event handlers');
                const privacyChoices = document.getElementById('wpcc-privacy-choices');
                if (privacyChoices) {
                    console.log('[WPCC] ✓ Privacy Choices link found');
                    privacyChoices.addEventListener('click', function(e) {
                        e.preventDefault();
                        console.log('[WPCC] Privacy Choices clicked - opening modal');
                        wpccOpenModal();
                    });
                } else {
                    console.warn('[WPCC] ✗ Privacy Choices link (#wpcc-privacy-choices) NOT FOUND');
                }

                const modalClose = document.getElementById('wpcc-modal-close');
                if (modalClose) {
                    console.log('[WPCC] ✓ Modal close button found');
                    modalClose.addEventListener('click', wpccCloseModal);
                } else {
                    console.warn('[WPCC] ✗ Modal close button NOT FOUND');
                }

                const modalOverlay = document.getElementById('wpcc-modal-overlay');
                if (modalOverlay) {
                    console.log('[WPCC] ✓ Modal overlay found');
                    modalOverlay.addEventListener('click', function(e) {
                        if (e.target === this) wpccCloseModal();
                    });
                    document.addEventListener('keydown', function(e) {
                        if (e.key === 'Escape' && modalOverlay.classList.contains('wpcc-open')) {
                            wpccCloseModal();
                        }
                    });
                } else {
                    console.warn('[WPCC] ✗ Modal overlay NOT FOUND');
                }

                const modalReject = document.getElementById('wpcc-modal-reject');
                if (modalReject) {
                    modalReject.addEventListener('click', wpccModalReject);
                }

                const modalSave = document.getElementById('wpcc-modal-save');
                if (modalSave) {
                    modalSave.addEventListener('click', wpccModalSave);
                }

                const toggleAnalytics = document.getElementById('wpcc-toggle-analytics');
                if (toggleAnalytics) {
                    toggleAnalytics.addEventListener('change', function() {
                        wpccUpdateToggleState(this, this.checked);
                    });
                }
            }
        }

        // Event listeners (for GDPR banner)
        if (acceptBtn) {
            acceptBtn.addEventListener('click', handleAccept);
        }

        if (rejectBtn) {
            rejectBtn.addEventListener('click', handleReject);
        }

        // Run on DOM ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            init();
        }
    })();
    ";
}

// ============================================
// ADMIN INTERFACE
// ============================================

// Add admin menu
add_action('admin_menu', 'wpcc_add_admin_menu');
function wpcc_add_admin_menu() {
    add_menu_page(
        'Cookie Consent',
        'Cookie Consent',
        'manage_options',
        'wp-cookie-consent',
        'wpcc_admin_page',
        'dashicons-privacy',
        30
    );

    add_submenu_page(
        'wp-cookie-consent',
        'Settings',
        'Settings',
        'manage_options',
        'wpcc-settings',
        'wpcc_settings_page'
    );
}

// Register settings
add_action('admin_init', 'wpcc_register_settings');
function wpcc_register_settings() {
    register_setting('wpcc_settings_group', 'wpcc_enabled');
    register_setting('wpcc_settings_group', 'wpcc_ga4_id');
    register_setting('wpcc_settings_group', 'wpcc_gtm_id');
    register_setting('wpcc_settings_group', 'wpcc_banner_title');
    register_setting('wpcc_settings_group', 'wpcc_banner_body');
    register_setting('wpcc_settings_group', 'wpcc_accept_label');
    register_setting('wpcc_settings_group', 'wpcc_reject_label');
    register_setting('wpcc_settings_group', 'wpcc_consent_expiry_days');

    // Color settings (banner)
    register_setting('wpcc_settings_group', 'wpcc_banner_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_banner_text_color');
    register_setting('wpcc_settings_group', 'wpcc_accept_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_accept_text_color');
    register_setting('wpcc_settings_group', 'wpcc_reject_border_color');

    // Learn more link
    register_setting('wpcc_settings_group', 'wpcc_learn_more_url');

    // Geolocation settings
    register_setting('wpcc_settings_group', 'wpcc_usa_mode');
    register_setting('wpcc_settings_group', 'wpcc_fallback_mode');
    register_setting('wpcc_settings_group', 'wpcc_disable_gdpr_banner');

    // Footer strip settings (USA/CCPA)
    register_setting('wpcc_settings_group', 'wpcc_footer_style');
    register_setting('wpcc_settings_group', 'wpcc_footer_copyright_text');
    register_setting('wpcc_settings_group', 'wpcc_footer_show_terms');
    register_setting('wpcc_settings_group', 'wpcc_footer_terms_label');
    register_setting('wpcc_settings_group', 'wpcc_footer_terms_url');
    register_setting('wpcc_settings_group', 'wpcc_footer_show_privacy');
    register_setting('wpcc_settings_group', 'wpcc_footer_privacy_label');
    register_setting('wpcc_settings_group', 'wpcc_footer_privacy_url');
    register_setting('wpcc_settings_group', 'wpcc_footer_show_cookies');
    register_setting('wpcc_settings_group', 'wpcc_footer_cookies_label');
    register_setting('wpcc_settings_group', 'wpcc_footer_cookies_url');
    register_setting('wpcc_settings_group', 'wpcc_footer_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_footer_text_color');
    register_setting('wpcc_settings_group', 'wpcc_footer_link_color');
    register_setting('wpcc_settings_group', 'wpcc_footer_copyright_color');

    // CF7 Script Optimization
    register_setting('wpcc_settings_group', 'wpcc_cf7_optimize');
    register_setting('wpcc_settings_group', 'wpcc_cf7_page_ids');
    register_setting('wpcc_settings_group', 'wpcc_cf7_recaptcha_text');
    register_setting('wpcc_settings_group', 'wpcc_cf7_recaptcha_font_size');
    register_setting('wpcc_settings_group', 'wpcc_cf7_recaptcha_color');
    register_setting('wpcc_settings_group', 'wpcc_cf7_recaptcha_align');

    // reCAPTCHA v3 Integration
    register_setting('wpcc_settings_group', 'wpcc_recaptcha_enabled');
    register_setting('wpcc_settings_group', 'wpcc_recaptcha_site_key');
    register_setting('wpcc_settings_group', 'wpcc_recaptcha_secret_key');
    register_setting('wpcc_settings_group', 'wpcc_recaptcha_threshold');
}

// Dashboard page
function wpcc_admin_page() {
    $is_enabled = get_option('wpcc_enabled', true);
    $ga4_id = get_option('wpcc_ga4_id', '');
    $has_ga4 = !empty($ga4_id);

    // Handle update cache refresh
    $cache_refreshed = false;
    if (isset($_POST['wpcc_refresh_cache']) && check_admin_referer('wpcc_refresh_cache', 'wpcc_refresh_nonce')) {
        delete_site_transient('update_plugins');
        $cache_refreshed = true;
    }
    ?>
    <div class="wrap">
        <h1>🍪 WP Cookie Consent</h1>
        <p><strong>Version:</strong> <?php echo WPCC_VERSION; ?> | <strong>Status:</strong> <?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></p>

        <?php if ($cache_refreshed): ?>
            <div class="notice notice-success is-dismissible">
                <p><strong>Update cache cleared!</strong> WordPress will check for plugin updates now.</p>
            </div>
        <?php endif; ?>

        <div class="card" style="max-width: 800px;">
            <h2>Plugin Status</h2>
            <table class="widefat" style="margin-top: 10px;">
                <tbody>
                    <tr>
                        <td style="width: 200px;"><strong>Cookie Banner:</strong></td>
                        <td><?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>GA4 Tracking ID:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ ' . esc_html($ga4_id) . '</span>' : '<span style="color: #f56e28;">⚠ Not configured</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Consent Mode v2:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ Ready</span>' : '<span style="color: #999;">○ Waiting for GA4 ID</span>'; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>🚀 Quick Start</h3>
            <ol>
                <li>Go to <a href="<?php echo admin_url('admin.php?page=wpcc-settings'); ?>">Settings</a> to configure your GA4 tracking ID</li>
                <li>Customize the cookie banner text and appearance</li>
                <li>Test the banner on your site (it will appear for first-time visitors)</li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>🔄 Update Cache Management</h3>
            <p>Use this button to clear the WordPress update cache and force a check for new plugin versions from GitHub.</p>
            <form method="post" style="margin-top: 15px;">
                <?php wp_nonce_field('wpcc_refresh_cache', 'wpcc_refresh_nonce'); ?>
                <button type="submit" name="wpcc_refresh_cache" class="button button-secondary">
                    🔄 Refresh Update Cache
                </button>
                <p class="description" style="margin-top: 10px;">Click this button after pushing a new release to GitHub to check for updates immediately.</p>
            </form>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 What's in v<?php echo WPCC_VERSION; ?></h3>
            <ul>
                <li><strong>GDPR-compliant cookie consent management</strong></li>
                <li><strong>Google Analytics 4 (GA4) integration with Consent Mode v2</strong></li>
                <li><strong>Equal prominence Accept/Reject buttons</strong> - no dark patterns</li>
                <li><strong>Auto-updates via GitHub</strong> - always get the latest version</li>
                <li><strong>Zero external dependencies</strong> - works on any WordPress site</li>
            </ul>
        </div>
    </div>
    <?php
}

// Settings page
function wpcc_settings_page() {
    if (isset($_POST['wpcc_settings_submit'])) {
        check_admin_referer('wpcc_settings_save', 'wpcc_settings_nonce');

        // Sanitize and save all settings
        update_option('wpcc_enabled', isset($_POST['wpcc_enabled']) ? 1 : 0);
        update_option('wpcc_ga4_id', sanitize_text_field($_POST['wpcc_ga4_id']));
        update_option('wpcc_gtm_id', sanitize_text_field($_POST['wpcc_gtm_id']));
        update_option('wpcc_banner_title', sanitize_text_field($_POST['wpcc_banner_title']));
        update_option('wpcc_banner_body', wp_kses_post($_POST['wpcc_banner_body']));
        update_option('wpcc_accept_label', sanitize_text_field($_POST['wpcc_accept_label']));
        update_option('wpcc_reject_label', sanitize_text_field($_POST['wpcc_reject_label']));
        update_option('wpcc_consent_expiry_days', absint($_POST['wpcc_consent_expiry_days']));

        // Color settings (banner)
        update_option('wpcc_banner_bg_color', sanitize_hex_color($_POST['wpcc_banner_bg_color']));
        update_option('wpcc_banner_text_color', sanitize_hex_color($_POST['wpcc_banner_text_color']));
        update_option('wpcc_accept_bg_color', sanitize_hex_color($_POST['wpcc_accept_bg_color']));
        update_option('wpcc_accept_text_color', sanitize_hex_color($_POST['wpcc_accept_text_color']));
        update_option('wpcc_reject_border_color', sanitize_hex_color($_POST['wpcc_reject_border_color']));

        // Learn more link
        update_option('wpcc_learn_more_url', esc_url_raw($_POST['wpcc_learn_more_url']));

        // Geolocation settings
        update_option('wpcc_usa_mode', sanitize_text_field($_POST['wpcc_usa_mode']));
        update_option('wpcc_fallback_mode', sanitize_text_field($_POST['wpcc_fallback_mode']));
        update_option('wpcc_disable_gdpr_banner', isset($_POST['wpcc_disable_gdpr_banner']) ? 1 : 0);

        // Footer strip settings
        update_option('wpcc_footer_style', sanitize_text_field($_POST['wpcc_footer_style']));
        update_option('wpcc_footer_copyright_text', wp_kses_post($_POST['wpcc_footer_copyright_text']));
        update_option('wpcc_footer_show_terms', isset($_POST['wpcc_footer_show_terms']) ? 1 : 0);
        update_option('wpcc_footer_terms_label', sanitize_text_field($_POST['wpcc_footer_terms_label']));
        update_option('wpcc_footer_terms_url', esc_url_raw($_POST['wpcc_footer_terms_url']));
        update_option('wpcc_footer_show_privacy', isset($_POST['wpcc_footer_show_privacy']) ? 1 : 0);
        update_option('wpcc_footer_privacy_label', sanitize_text_field($_POST['wpcc_footer_privacy_label']));
        update_option('wpcc_footer_privacy_url', esc_url_raw($_POST['wpcc_footer_privacy_url']));
        update_option('wpcc_footer_show_cookies', isset($_POST['wpcc_footer_show_cookies']) ? 1 : 0);
        update_option('wpcc_footer_cookies_label', sanitize_text_field($_POST['wpcc_footer_cookies_label']));
        update_option('wpcc_footer_cookies_url', esc_url_raw($_POST['wpcc_footer_cookies_url']));
        update_option('wpcc_footer_bg_color', sanitize_text_field($_POST['wpcc_footer_bg_color']));
        update_option('wpcc_footer_text_color', sanitize_text_field($_POST['wpcc_footer_text_color']));
        update_option('wpcc_footer_link_color', sanitize_text_field($_POST['wpcc_footer_link_color']));
        update_option('wpcc_footer_copyright_color', sanitize_text_field($_POST['wpcc_footer_copyright_color']));

        // CF7 Script Optimization
        update_option('wpcc_cf7_optimize', isset($_POST['wpcc_cf7_optimize']) ? 1 : 0);
        update_option('wpcc_cf7_page_ids', sanitize_text_field($_POST['wpcc_cf7_page_ids']));
        update_option('wpcc_cf7_recaptcha_text', wp_kses_post($_POST['wpcc_cf7_recaptcha_text']));
        update_option('wpcc_cf7_recaptcha_font_size', intval($_POST['wpcc_cf7_recaptcha_font_size']));
        update_option('wpcc_cf7_recaptcha_color', sanitize_text_field($_POST['wpcc_cf7_recaptcha_color']));
        update_option('wpcc_cf7_recaptcha_align', sanitize_text_field($_POST['wpcc_cf7_recaptcha_align']));

        // reCAPTCHA v3 Integration
        update_option('wpcc_recaptcha_enabled', isset($_POST['wpcc_recaptcha_enabled']) ? 1 : 0);
        update_option('wpcc_recaptcha_site_key', sanitize_text_field($_POST['wpcc_recaptcha_site_key']));
        update_option('wpcc_recaptcha_secret_key', sanitize_text_field($_POST['wpcc_recaptcha_secret_key']));
        update_option('wpcc_recaptcha_threshold', floatval($_POST['wpcc_recaptcha_threshold']));

        echo '<div class="notice notice-success is-dismissible"><p><strong>Settings saved successfully!</strong></p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Cookie Consent Settings</h1>
        <p>Configure your GDPR-compliant cookie consent banner and Google Analytics integration.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpcc_settings_save', 'wpcc_settings_nonce'); ?>

            <h2>General Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_enabled">Enable Cookie Banner</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpcc_enabled" id="wpcc_enabled" value="1" <?php checked(get_option('wpcc_enabled', true)); ?>>
                            Show cookie consent banner on the site
                        </label>
                        <p class="description">Master on/off switch for the entire cookie consent system.</p>
                    </td>
                </tr>
            </table>

            <h2>Geolocation Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label>Current Visitor</label>
                    </th>
                    <td>
                        <?php
                        $country = wpcc_get_country_code();
                        $is_gdpr = wpcc_is_gdpr_country($country);
                        $mode = wpcc_get_consent_mode();
                        ?>
                        <p style="margin: 0; padding: 0.5rem; background: #f0f6fc; border-left: 3px solid #0969da; display: inline-block;">
                            <strong>Country Code:</strong> <?php echo $country ? esc_html($country) : 'Unknown (Cloudflare header not detected)'; ?><br>
                            <strong>GDPR Country:</strong> <?php echo $is_gdpr ? '✓ Yes' : '✗ No'; ?><br>
                            <strong>UI Mode:</strong> <?php echo esc_html(ucfirst($mode)); ?>
                        </p>
                        <p class="description">
                            This plugin uses Cloudflare's HTTP_CF_IPCOUNTRY header to detect visitor location.<br>
                            <strong>GDPR countries (EU/EEA/UK):</strong> Show full cookie consent banner<br>
                            <strong>USA:</strong> Show "Your Privacy Choices" footer strip (CCPA compliant)<br>
                            <strong>Others:</strong> Use fallback mode (banner for safety)
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_usa_mode">USA Visitor Mode</label>
                    </th>
                    <td>
                        <select name="wpcc_usa_mode" id="wpcc_usa_mode">
                            <option value="footer" <?php selected(get_option('wpcc_usa_mode', 'footer'), 'footer'); ?>>Footer Strip (CCPA - recommended)</option>
                            <option value="banner" <?php selected(get_option('wpcc_usa_mode', 'footer'), 'banner'); ?>>Full Banner (GDPR-style)</option>
                        </select>
                        <p class="description">Choose what USA visitors see. Footer strip is CCPA-compliant and less intrusive.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_fallback_mode">Fallback Mode</label>
                    </th>
                    <td>
                        <select name="wpcc_fallback_mode" id="wpcc_fallback_mode">
                            <option value="banner" <?php selected(get_option('wpcc_fallback_mode', 'banner'), 'banner'); ?>>Banner (safer for compliance)</option>
                            <option value="footer" <?php selected(get_option('wpcc_fallback_mode', 'banner'), 'footer'); ?>>Footer Strip</option>
                        </select>
                        <p class="description">What to show when geolocation is unavailable (no Cloudflare header detected).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_disable_gdpr_banner">Disable GDPR Banner</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpcc_disable_gdpr_banner" id="wpcc_disable_gdpr_banner" value="1" <?php checked(get_option('wpcc_disable_gdpr_banner', false)); ?>>
                            Hide cookie banner for EU/GDPR visitors
                        </label>
                        <p class="description">When enabled, EU/GDPR visitors will NOT see the cookie consent banner. Only USA visitors will see the footer strip. Use this to show consent UI only to USA visitors.</p>
                    </td>
                </tr>
            </table>

            <h2>Google Analytics Configuration</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_ga4_id">GA4 Measurement ID</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_ga4_id" id="wpcc_ga4_id" value="<?php echo esc_attr(get_option('wpcc_ga4_id', '')); ?>" class="regular-text" placeholder="G-XXXXXXXXXX">
                        <p class="description">Enter your Google Analytics 4 Measurement ID (format: G-XXXXXXXXXX). Leave empty to disable GA4 tracking.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_gtm_id">Google Tag Manager Container ID</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_gtm_id" id="wpcc_gtm_id" value="<?php echo esc_attr(get_option('wpcc_gtm_id', '')); ?>" class="regular-text" placeholder="GTM-XXXXXXXX">
                        <p class="description">Enter your GTM Container ID (format: GTM-XXXXXXXX). Leave empty if not using GTM. <strong>Note:</strong> If you have GTM hardcoded in your theme or another plugin, remove it and enter the ID here to ensure consent compliance.</p>
                    </td>
                </tr>
            </table>

            <h2>Banner Content</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_title">Banner Title</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_banner_title" id="wpcc_banner_title" value="<?php echo esc_attr(get_option('wpcc_banner_title', 'We use cookies')); ?>" class="regular-text">
                        <p class="description">Note: the title is hidden in the pill layout. Use the body text field only.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_body">Banner Message</label>
                    </th>
                    <td>
                        <textarea name="wpcc_banner_body" id="wpcc_banner_body" rows="4" class="large-text"><?php echo esc_textarea(get_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.')); ?></textarea>
                        <p class="description">The main message displayed in the cookie banner. HTML allowed (links, bold, etc.).</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_label">Accept Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_accept_label" id="wpcc_accept_label" value="<?php echo esc_attr(get_option('wpcc_accept_label', 'Accept')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_reject_label">Reject Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_reject_label" id="wpcc_reject_label" value="<?php echo esc_attr(get_option('wpcc_reject_label', 'Reject')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_learn_more_url">"Learn More" Link URL</label>
                    </th>
                    <td>
                        <input type="url" name="wpcc_learn_more_url" id="wpcc_learn_more_url" value="<?php echo esc_attr(get_option('wpcc_learn_more_url', '/privacy-policy#cookies')); ?>" class="regular-text" placeholder="/privacy-policy#cookies">
                        <p class="description">URL for the "Learn more" link in the banner. Can be a relative path (e.g., /privacy-policy#cookies) or full URL.</p>
                    </td>
                </tr>
            </table>

            <h2>Appearance & Colors</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_bg_color">Banner Background</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_banner_bg_color" id="wpcc_banner_bg_color" value="<?php echo esc_attr(get_option('wpcc_banner_bg_color', '#ffffff')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_banner_bg_color', '#ffffff')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Background color of the cookie banner.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_text_color">Banner Text</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_banner_text_color" id="wpcc_banner_text_color" value="<?php echo esc_attr(get_option('wpcc_banner_text_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_banner_text_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Text color in the banner.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_bg_color">Accept Button Background</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_accept_bg_color" id="wpcc_accept_bg_color" value="<?php echo esc_attr(get_option('wpcc_accept_bg_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_accept_bg_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Background color of the Accept button.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_text_color">Accept Button Text</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_accept_text_color" id="wpcc_accept_text_color" value="<?php echo esc_attr(get_option('wpcc_accept_text_color', '#ffffff')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_accept_text_color', '#ffffff')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Text color of the Accept button.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_reject_border_color">Reject Button Border</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_reject_border_color" id="wpcc_reject_border_color" value="<?php echo esc_attr(get_option('wpcc_reject_border_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_reject_border_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Border and text color of the Reject button.</p>
                    </td>
                </tr>
            </table>

            <h2>Behavior Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_consent_expiry_days">Consent Expiry (Days)</label>
                    </th>
                    <td>
                        <input type="number" name="wpcc_consent_expiry_days" id="wpcc_consent_expiry_days" value="<?php echo esc_attr(get_option('wpcc_consent_expiry_days', 180)); ?>" min="1" max="365" class="small-text">
                        <p class="description">Number of days before asking for consent again (1-365 days).</p>
                    </td>
                </tr>
            </table>

            <h2>Footer Strip Settings (USA/CCPA)</h2>
            <p style="background: #f0f6fc; padding: 1rem; border-left: 3px solid #0969da;">
                These settings apply when <strong>USA Visitor Mode</strong> is set to "Footer Strip" (CCPA compliance).<br>
                The footer strip shows a "Your Privacy Choices" link with the official CCPA opt-out icon.
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_copyright_text">Copyright Text</label>
                    </th>
                    <td>
                        <textarea name="wpcc_footer_copyright_text" id="wpcc_footer_copyright_text" rows="3" class="large-text"><?php echo esc_textarea(get_option('wpcc_footer_copyright_text', '© {year} {site_name} | Powered by <a href="https://marketingaid.com" target="_blank" rel="noopener noreferrer">MarketingAid</a>')); ?></textarea>
                        <p class="description">
                            Customize the copyright text with full HTML support. Available tokens:<br>
                            <code>{year}</code> = Current year (e.g., <?php echo date('Y'); ?>)<br>
                            <code>{site_name}</code> = Site name (<?php echo esc_html(get_bloginfo('name')); ?>)<br>
                            <strong>Examples:</strong><br>
                            <code>© {year} {site_name}</code> (for MarketingAid's own site)<br>
                            <code>© {year} {site_name} | Powered by &lt;a href="https://marketingaid.com" target="_blank"&gt;MarketingAid&lt;/a&gt;</code> (for client sites)
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_show_terms">Link 1</label>
                    </th>
                    <td>
                        <label style="margin-bottom: 0.5rem; display: block;">
                            <input type="checkbox" name="wpcc_footer_show_terms" id="wpcc_footer_show_terms" value="1" <?php checked(get_option('wpcc_footer_show_terms', true)); ?>>
                            Show this link
                        </label>
                        <input type="text" name="wpcc_footer_terms_label" id="wpcc_footer_terms_label" value="<?php echo esc_attr(get_option('wpcc_footer_terms_label', 'Terms of Service')); ?>" class="regular-text" placeholder="Link Text" style="margin-bottom: 0.5rem;">
                        <input type="url" name="wpcc_footer_terms_url" id="wpcc_footer_terms_url" value="<?php echo esc_attr(get_option('wpcc_footer_terms_url', '/terms-of-service')); ?>" class="regular-text" placeholder="/url-or-path">
                        <p class="description">Customize label and URL. Use for Terms, Sitemap, or any custom link.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_show_privacy">Link 2</label>
                    </th>
                    <td>
                        <label style="margin-bottom: 0.5rem; display: block;">
                            <input type="checkbox" name="wpcc_footer_show_privacy" id="wpcc_footer_show_privacy" value="1" <?php checked(get_option('wpcc_footer_show_privacy', true)); ?>>
                            Show this link
                        </label>
                        <input type="text" name="wpcc_footer_privacy_label" id="wpcc_footer_privacy_label" value="<?php echo esc_attr(get_option('wpcc_footer_privacy_label', 'Privacy Policy')); ?>" class="regular-text" placeholder="Link Text" style="margin-bottom: 0.5rem;">
                        <input type="url" name="wpcc_footer_privacy_url" id="wpcc_footer_privacy_url" value="<?php echo esc_attr(get_option('wpcc_footer_privacy_url', '/privacy-policy')); ?>" class="regular-text" placeholder="/url-or-path">
                        <p class="description">Customize label and URL. Use for Privacy Policy or any custom link.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_show_cookies">Link 3</label>
                    </th>
                    <td>
                        <label style="margin-bottom: 0.5rem; display: block;">
                            <input type="checkbox" name="wpcc_footer_show_cookies" id="wpcc_footer_show_cookies" value="1" <?php checked(get_option('wpcc_footer_show_cookies', true)); ?>>
                            Show this link
                        </label>
                        <input type="text" name="wpcc_footer_cookies_label" id="wpcc_footer_cookies_label" value="<?php echo esc_attr(get_option('wpcc_footer_cookies_label', 'Cookie Policy')); ?>" class="regular-text" placeholder="Link Text" style="margin-bottom: 0.5rem;">
                        <input type="url" name="wpcc_footer_cookies_url" id="wpcc_footer_cookies_url" value="<?php echo esc_attr(get_option('wpcc_footer_cookies_url', '/cookie-policy')); ?>" class="regular-text" placeholder="/url-or-path">
                        <p class="description">Customize label and URL. Use for Cookie Policy, Sitemap, or any custom link.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_bg_color">Footer Background</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_footer_bg_color" id="wpcc_footer_bg_color" value="<?php echo esc_attr(get_option('wpcc_footer_bg_color', '#0d0b08')); ?>" class="regular-text">
                        <p class="description">CSS color value (e.g., #0d0b08 or rgba(13,11,8,1)).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_text_color">Footer Text Color</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_footer_text_color" id="wpcc_footer_text_color" value="<?php echo esc_attr(get_option('wpcc_footer_text_color', 'rgba(255,255,255,0.38)')); ?>" class="regular-text">
                        <p class="description">CSS color value for main text (e.g., rgba(255,255,255,0.38)).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_link_color">Footer Link Color</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_footer_link_color" id="wpcc_footer_link_color" value="<?php echo esc_attr(get_option('wpcc_footer_link_color', 'rgba(255,255,255,0.6)')); ?>" class="regular-text">
                        <p class="description">CSS color value for links (e.g., rgba(255,255,255,0.6)).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_footer_copyright_color">Copyright Text Color</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_footer_copyright_color" id="wpcc_footer_copyright_color" value="<?php echo esc_attr(get_option('wpcc_footer_copyright_color', 'rgba(255,255,255,0.6)')); ?>" class="regular-text">
                        <p class="description">CSS color value for copyright text (e.g., rgba(255,255,255,0.8) for brighter).</p>
                    </td>
                </tr>
            </table>

            <h2>CF7 Script Optimization</h2>
            <p style="background: #fff3cd; padding: 1rem; border-left: 3px solid #ffc107;">
                <strong>Contact Form 7 Performance:</strong> By default, CF7 loads scripts on every page, even where they're not needed. Enable optimization to load CF7 scripts only on specific pages.<br>
                This is especially useful for sites using Elementor or WPBakery Page Builder where forms are embedded via page builder.
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_cf7_optimize">Optimize CF7 Scripts</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpcc_cf7_optimize" id="wpcc_cf7_optimize" value="1" <?php checked(get_option('wpcc_cf7_optimize', false)); ?>>
                            Only load Contact Form 7 scripts on specified pages
                        </label>
                        <p class="description">When enabled, CF7 scripts will ONLY load on the pages you specify below.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_cf7_page_ids">Page IDs with CF7 Forms</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_cf7_page_ids" id="wpcc_cf7_page_ids" value="<?php echo esc_attr(get_option('wpcc_cf7_page_ids', '')); ?>" class="regular-text" placeholder="42, 87, 123">
                        <p class="description">
                            Enter page IDs where CF7 forms are used, separated by commas (e.g., <code>42, 87, 123</code>).<br>
                            <strong>How to find Page IDs:</strong> Go to <strong>Pages → All Pages</strong> and hover over a page title — the ID appears in the URL bar as <code>post=123</code>
                        </p>
                    </td>
                </tr>
            </table>

            <h2>CF7 reCAPTCHA Notice</h2>
            <p style="background: #fff3cd; padding: 1rem; border-left: 3px solid #ffc107;">
                <strong>Visual Customization:</strong> Customize how the reCAPTCHA notice appears below form submit buttons.<br>
                This sleek, minimal notice only shows on pages with CF7 forms - no site-wide clutter.<br>
                <strong>Important:</strong> Make sure to enable "reCAPTCHA v3 Integration" below and add your keys for full protection.
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_cf7_recaptcha_text">reCAPTCHA Notice Text</label>
                    </th>
                    <td>
                        <textarea name="wpcc_cf7_recaptcha_text" id="wpcc_cf7_recaptcha_text" rows="3" class="large-text"><?php echo esc_textarea(get_option('wpcc_cf7_recaptcha_text', 'This site is protected by reCAPTCHA. <a href="https://policies.google.com/privacy" target="_blank">Privacy</a> - <a href="https://policies.google.com/terms" target="_blank">Terms</a>')); ?></textarea>
                        <p class="description">Text shown below CF7 form submit buttons. HTML allowed (links).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_cf7_recaptcha_font_size">Font Size (px)</label>
                    </th>
                    <td>
                        <input type="number" name="wpcc_cf7_recaptcha_font_size" id="wpcc_cf7_recaptcha_font_size" value="<?php echo esc_attr(get_option('wpcc_cf7_recaptcha_font_size', '11')); ?>" min="8" max="20" class="small-text">
                        <p class="description">Font size in pixels (8-20px recommended). Default: 11px.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_cf7_recaptcha_color">Text Color</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_cf7_recaptcha_color" id="wpcc_cf7_recaptcha_color" value="<?php echo esc_attr(get_option('wpcc_cf7_recaptcha_color', '#999999')); ?>" class="regular-text" placeholder="#999999">
                        <p class="description">CSS color value (e.g., #999999 or rgba(153,153,153,1)).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_cf7_recaptcha_align">Text Alignment</label>
                    </th>
                    <td>
                        <select name="wpcc_cf7_recaptcha_align" id="wpcc_cf7_recaptcha_align">
                            <option value="left" <?php selected(get_option('wpcc_cf7_recaptcha_align', 'left'), 'left'); ?>>Left (align with button)</option>
                            <option value="center" <?php selected(get_option('wpcc_cf7_recaptcha_align', 'left'), 'center'); ?>>Center</option>
                            <option value="right" <?php selected(get_option('wpcc_cf7_recaptcha_align', 'left'), 'right'); ?>>Right</option>
                        </select>
                        <p class="description">Choose how the notice aligns below the submit button.</p>
                    </td>
                </tr>
            </table>

            <h2>reCAPTCHA v3 Integration</h2>
            <p style="background: #d1f4e0; padding: 1rem; border-left: 3px solid #28a745;">
                <strong>Full reCAPTCHA v3 Protection:</strong> Add Google reCAPTCHA v3 to your CF7 forms with complete control over script loading.<br>
                Only loads on pages with CF7 forms - no site-wide scripts. Get your keys from <a href="https://www.google.com/recaptcha/admin" target="_blank">Google reCAPTCHA Admin</a>.
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_recaptcha_enabled">Enable reCAPTCHA v3</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpcc_recaptcha_enabled" id="wpcc_recaptcha_enabled" value="1" <?php checked(get_option('wpcc_recaptcha_enabled', false)); ?>>
                            Enable reCAPTCHA v3 protection for CF7 forms
                        </label>
                        <p class="description">When enabled, reCAPTCHA v3 will validate all CF7 form submissions.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_recaptcha_site_key">Site Key</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_recaptcha_site_key" id="wpcc_recaptcha_site_key" value="<?php echo esc_attr(get_option('wpcc_recaptcha_site_key', '')); ?>" class="regular-text" placeholder="6Lc...">
                        <p class="description">Your reCAPTCHA v3 Site Key (public key) from Google.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_recaptcha_secret_key">Secret Key</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_recaptcha_secret_key" id="wpcc_recaptcha_secret_key" value="<?php echo esc_attr(get_option('wpcc_recaptcha_secret_key', '')); ?>" class="regular-text" placeholder="6Lc...">
                        <p class="description">Your reCAPTCHA v3 Secret Key (private key) from Google. Keep this secure!</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_recaptcha_threshold">Score Threshold</label>
                    </th>
                    <td>
                        <input type="number" name="wpcc_recaptcha_threshold" id="wpcc_recaptcha_threshold" value="<?php echo esc_attr(get_option('wpcc_recaptcha_threshold', '0.5')); ?>" min="0" max="1" step="0.1" class="small-text">
                        <p class="description">Minimum score required (0.0 to 1.0). Lower = more strict. Default: 0.5 (recommended).</p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpcc_settings_submit" class="button button-primary" value="Save Settings">
            </p>

            <script>
            // Update text inputs when color pickers change
            document.querySelectorAll('.wpcc-color-picker').forEach(function(picker) {
                picker.addEventListener('input', function() {
                    this.nextElementSibling.value = this.value;
                });
            });
            </script>
        </form>
    </div>
    <?php
}

