<?php
/**
 * Plugin Name: WP Cookie Consent
 * Plugin URI: https://github.com/hyveli/wp-cookie-consent
 * Description: GDPR-compliant cookie consent management with Google Analytics 4 (GA4) support and Consent Mode v2 integration.
 * Version: 1.0.5
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Kara Concepcion
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-cookie-consent
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPCC_VERSION', '1.0.5');
define('WPCC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPCC_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    // Prevent loading the autoloader multiple times
    if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        require_once __DIR__ . '/vendor/autoload.php';
    }

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-cookie-consent-dist/main/release.json',
            __FILE__,
            'wp-cookie-consent'
        );

        // Force update check if URL parameter is present
        if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
            delete_site_transient('update_plugins');
            $updateChecker->checkForUpdates();
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>✅ Update check cache cleared! WordPress will check for updates now.</p></div>';
            });
        }
    }
}

// Activation hook
register_activation_hook(__FILE__, 'wpcc_activate');
function wpcc_activate() {
    // Set default options on activation
    add_option('wpcc_enabled', true);
    add_option('wpcc_ga4_id', '');
    add_option('wpcc_banner_title', 'We use cookies');
    add_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.');
    add_option('wpcc_accept_label', 'Accept');
    add_option('wpcc_reject_label', 'Reject');
    add_option('wpcc_consent_expiry_days', 180);

    // Color options
    add_option('wpcc_banner_bg_color', '#ffffff');
    add_option('wpcc_banner_text_color', '#111111');
    add_option('wpcc_accept_bg_color', '#111111');
    add_option('wpcc_accept_text_color', '#ffffff');
    add_option('wpcc_reject_border_color', '#111111');

    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpcc_deactivate');
function wpcc_deactivate() {
    flush_rewrite_rules();
}

// ============================================
// COOKIE CONSENT FEATURES
// ============================================

// Output banner styles in head
add_action('wp_head', 'wpcc_output_styles', 100);
function wpcc_output_styles() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }
    echo '<style id="wpcc-banner-styles">' . wpcc_get_banner_styles() . '</style>';
}

// Output consent script in footer
add_action('wp_footer', 'wpcc_output_script', 20);
function wpcc_output_script() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }
    echo '<script id="wpcc-consent-script">' . wpcc_get_consent_script() . '</script>';
}

// Add Consent Mode v2 script to <head> (must be first)
add_action('wp_head', 'wpcc_render_consent_mode', 1);
function wpcc_render_consent_mode() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }

    $ga4_id = get_option('wpcc_ga4_id', '');
    if (empty($ga4_id)) {
        return;
    }
    ?>
    <!-- Google Consent Mode v2 -->
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('consent', 'default', {
        'analytics_storage': 'denied',
        'ad_storage': 'denied',
        'functionality_storage': 'denied',
        'personalization_storage': 'denied',
        'wait_for_update': 500
    });
    gtag('js', new Date());
    </script>
    <?php
}

// Render cookie banner in footer
add_action('wp_footer', 'wpcc_render_banner', 5);
function wpcc_render_banner() {
    if (!get_option('wpcc_enabled', true)) {
        return;
    }

    $title = get_option('wpcc_banner_title', 'We use cookies');
    $body = get_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.');
    $accept_label = get_option('wpcc_accept_label', 'Accept');
    $reject_label = get_option('wpcc_reject_label', 'Reject');
    $ga4_id = get_option('wpcc_ga4_id', '');
    $expiry_days = get_option('wpcc_consent_expiry_days', 180);
    ?>
    <div id="wpcc-banner" class="wpcc-banner wpcc-banner--bottom wpcc-banner--light" role="dialog" aria-modal="false" aria-live="polite" aria-label="Cookie consent" style="display:none;">
        <div class="wpcc-banner__inner">
            <div class="wpcc-banner__content">
                <?php if ($title): ?>
                    <p class="wpcc-banner__title"><strong><?php echo esc_html($title); ?></strong></p>
                <?php endif; ?>
                <p class="wpcc-banner__body"><?php echo wp_kses_post($body); ?></p>
            </div>
            <div class="wpcc-banner__actions">
                <button id="wpcc-reject" class="wpcc-btn wpcc-btn--secondary" type="button" aria-label="<?php echo esc_attr($reject_label); ?>">
                    <?php echo esc_html($reject_label); ?>
                </button>
                <button id="wpcc-accept" class="wpcc-btn wpcc-btn--primary" type="button" aria-label="<?php echo esc_attr($accept_label); ?>">
                    <?php echo esc_html($accept_label); ?>
                </button>
            </div>
        </div>
    </div>

    <script>
    // Pass PHP variables to JavaScript
    window.wpccConfig = {
        ga4Id: '<?php echo esc_js($ga4_id); ?>',
        expiryDays: <?php echo absint($expiry_days); ?>
    };
    </script>
    <?php
}

// Get banner CSS
function wpcc_get_banner_styles() {
    $banner_bg = get_option('wpcc_banner_bg_color', '#ffffff');
    $banner_text = get_option('wpcc_banner_text_color', '#111111');
    $accept_bg = get_option('wpcc_accept_bg_color', '#111111');
    $accept_text = get_option('wpcc_accept_text_color', '#ffffff');
    $reject_border = get_option('wpcc_reject_border_color', '#111111');

    return '
    .wpcc-banner {
        position: fixed;
        left: 0;
        right: 0;
        z-index: 999999;
        background: ' . esc_attr($banner_bg) . ';
        color: ' . esc_attr($banner_text) . ';
        border-top: 1px solid rgba(0,0,0,0.1);
        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
        padding: 1.25rem;
    }

    .wpcc-banner--bottom {
        bottom: 0;
    }

    .wpcc-banner--light {
        --wpcc-bg: ' . esc_attr($banner_bg) . ';
        --wpcc-text: ' . esc_attr($banner_text) . ';
        --wpcc-border: rgba(0,0,0,0.1);
        --wpcc-btn-primary-bg: ' . esc_attr($accept_bg) . ';
        --wpcc-btn-primary-text: ' . esc_attr($accept_text) . ';
        --wpcc-btn-secondary-bg: transparent;
        --wpcc-btn-secondary-text: ' . esc_attr($banner_text) . ';
        --wpcc-btn-secondary-border: ' . esc_attr($reject_border) . ';
    }

    .wpcc-banner__inner {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 2rem;
        flex-wrap: wrap;
    }

    .wpcc-banner__content {
        flex: 1 1 300px;
    }

    .wpcc-banner__title {
        margin: 0 0 0.5rem 0;
        font-size: 1rem;
        font-weight: 600;
    }

    .wpcc-banner__body {
        margin: 0;
        font-size: 0.9rem;
        line-height: 1.4;
    }

    .wpcc-banner__actions {
        display: flex;
        gap: 1rem;
        flex-shrink: 0;
    }

    .wpcc-btn {
        padding: 0.75rem 1.5rem;
        border: 2px solid;
        border-radius: 4px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        min-width: 100px;
        min-height: 44px;
    }

    .wpcc-btn--primary {
        background: var(--wpcc-btn-primary-bg);
        color: var(--wpcc-btn-primary-text);
        border-color: var(--wpcc-btn-primary-bg);
    }

    .wpcc-btn--primary:hover {
        opacity: 0.9;
    }

    .wpcc-btn--primary:focus-visible {
        outline: 3px solid #005FCC;
        outline-offset: 2px;
    }

    .wpcc-btn--secondary {
        background: var(--wpcc-btn-secondary-bg);
        color: var(--wpcc-btn-secondary-text);
        border-color: var(--wpcc-btn-secondary-border);
    }

    .wpcc-btn--secondary:hover {
        background: rgba(0,0,0,0.05);
    }

    .wpcc-btn--secondary:focus-visible {
        outline: 3px solid #005FCC;
        outline-offset: 2px;
    }

    @media (max-width: 768px) {
        .wpcc-banner {
            padding: 1rem;
        }

        .wpcc-banner__inner {
            flex-direction: column;
            align-items: stretch;
            gap: 1rem;
        }

        .wpcc-banner__title {
            font-size: 0.95rem;
            margin-bottom: 0.35rem;
        }

        .wpcc-banner__body {
            font-size: 0.85rem;
            line-height: 1.35;
        }

        .wpcc-banner__actions {
            flex-direction: row;
            gap: 0.75rem;
        }

        .wpcc-btn {
            width: 100%;
            padding: 0.65rem 1rem;
            font-size: 0.9rem;
        }
    }
    ';
}

// Get consent JavaScript
function wpcc_get_consent_script() {
    return "
    (function() {
        'use strict';

        const CONSENT_KEY = 'wpcc_consent';
        const banner = document.getElementById('wpcc-banner');
        const acceptBtn = document.getElementById('wpcc-accept');
        const rejectBtn = document.getElementById('wpcc-reject');
        const config = window.wpccConfig || {};

        // Check if consent exists and is valid
        function hasValidConsent() {
            try {
                const stored = localStorage.getItem(CONSENT_KEY);
                if (!stored) {
                    console.log('[WPCC] No stored consent found');
                    return null;
                }

                const data = JSON.parse(stored);
                const now = Date.now();

                if (now > data.expires) {
                    console.log('[WPCC] Stored consent expired');
                    localStorage.removeItem(CONSENT_KEY);
                    return null;
                }

                console.log('[WPCC] Valid consent found:', data.value);
                return data.value; // 'accepted' or 'rejected'
            } catch (e) {
                console.error('[WPCC] Error reading consent:', e);
                return null;
            }
        }

        // Save consent decision
        function saveConsent(value) {
            const expiryMs = (config.expiryDays || 180) * 24 * 60 * 60 * 1000;
            const data = {
                value: value,
                expires: Date.now() + expiryMs
            };
            localStorage.setItem(CONSENT_KEY, JSON.stringify(data));
            console.log('[WPCC] Consent saved:', value, '(expires in ' + config.expiryDays + ' days)');
        }

        // Load GA4 tracking
        function loadGA4() {
            if (!config.ga4Id) {
                console.log('[WPCC] No GA4 ID configured - skipping GA4 load');
                return;
            }

            // Check if already loaded
            if (document.querySelector('script[src*=\"' + config.ga4Id + '\"]')) {
                console.log('[WPCC] GA4 already loaded');
                return;
            }

            console.log('[WPCC] Loading GA4 tracking with ID:', config.ga4Id);

            // Create and append GA4 script
            const script = document.createElement('script');
            script.async = true;
            script.src = 'https://www.googletagmanager.com/gtag/js?id=' + config.ga4Id;
            document.head.appendChild(script);

            // Update consent mode
            if (typeof gtag === 'function') {
                gtag('consent', 'update', {
                    'analytics_storage': 'granted'
                });
                gtag('config', config.ga4Id);
                console.log('[WPCC] GA4 consent updated to GRANTED');
            } else {
                console.warn('[WPCC] gtag function not available yet - consent will update when GA4 loads');
            }
        }

        // Show banner
        function showBanner() {
            if (banner) {
                console.log('[WPCC] Showing cookie consent banner');
                banner.style.display = 'block';
                // Focus on first button (reject) for accessibility
                setTimeout(function() {
                    if (rejectBtn) rejectBtn.focus();
                }, 100);
            }
        }

        // Hide banner
        function hideBanner() {
            if (banner) {
                console.log('[WPCC] Hiding banner');
                banner.style.display = 'none';
            }
        }

        // Handle accept
        function handleAccept() {
            console.log('[WPCC] User clicked ACCEPT');
            saveConsent('accepted');
            loadGA4();
            hideBanner();
        }

        // Handle reject
        function handleReject() {
            console.log('[WPCC] User clicked REJECT - GA4 will NOT be loaded');
            saveConsent('rejected');
            hideBanner();
        }

        // Initialize
        function init() {
            console.log('[WPCC] Initializing cookie consent system');
            const consent = hasValidConsent();

            if (consent === 'accepted') {
                console.log('[WPCC] Previous consent: ACCEPTED - loading GA4');
                loadGA4();
            } else if (consent === null) {
                console.log('[WPCC] No previous consent - showing banner');
                showBanner();
            } else {
                console.log('[WPCC] Previous consent: REJECTED - GA4 will not load');
            }
        }

        // Event listeners
        if (acceptBtn) {
            acceptBtn.addEventListener('click', handleAccept);
        }

        if (rejectBtn) {
            rejectBtn.addEventListener('click', handleReject);
        }

        // Run on DOM ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            init();
        }
    })();
    ";
}

// ============================================
// ADMIN INTERFACE
// ============================================

// Add admin menu
add_action('admin_menu', 'wpcc_add_admin_menu');
function wpcc_add_admin_menu() {
    add_menu_page(
        'Cookie Consent',
        'Cookie Consent',
        'manage_options',
        'wp-cookie-consent',
        'wpcc_admin_page',
        'dashicons-privacy',
        30
    );

    add_submenu_page(
        'wp-cookie-consent',
        'Settings',
        'Settings',
        'manage_options',
        'wpcc-settings',
        'wpcc_settings_page'
    );
}

// Register settings
add_action('admin_init', 'wpcc_register_settings');
function wpcc_register_settings() {
    register_setting('wpcc_settings_group', 'wpcc_enabled');
    register_setting('wpcc_settings_group', 'wpcc_ga4_id');
    register_setting('wpcc_settings_group', 'wpcc_banner_title');
    register_setting('wpcc_settings_group', 'wpcc_banner_body');
    register_setting('wpcc_settings_group', 'wpcc_accept_label');
    register_setting('wpcc_settings_group', 'wpcc_reject_label');
    register_setting('wpcc_settings_group', 'wpcc_consent_expiry_days');

    // Color settings
    register_setting('wpcc_settings_group', 'wpcc_banner_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_banner_text_color');
    register_setting('wpcc_settings_group', 'wpcc_accept_bg_color');
    register_setting('wpcc_settings_group', 'wpcc_accept_text_color');
    register_setting('wpcc_settings_group', 'wpcc_reject_border_color');
}

// Dashboard page
function wpcc_admin_page() {
    $is_enabled = get_option('wpcc_enabled', true);
    $ga4_id = get_option('wpcc_ga4_id', '');
    $has_ga4 = !empty($ga4_id);

    // Handle update cache refresh
    $cache_refreshed = false;
    if (isset($_POST['wpcc_refresh_cache']) && check_admin_referer('wpcc_refresh_cache', 'wpcc_refresh_nonce')) {
        delete_site_transient('update_plugins');
        $cache_refreshed = true;
    }
    ?>
    <div class="wrap">
        <h1>🍪 WP Cookie Consent</h1>
        <p><strong>Version:</strong> <?php echo WPCC_VERSION; ?> | <strong>Status:</strong> <?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></p>

        <?php if ($cache_refreshed): ?>
            <div class="notice notice-success is-dismissible">
                <p><strong>Update cache cleared!</strong> WordPress will check for plugin updates now.</p>
            </div>
        <?php endif; ?>

        <div class="card" style="max-width: 800px;">
            <h2>Plugin Status</h2>
            <table class="widefat" style="margin-top: 10px;">
                <tbody>
                    <tr>
                        <td style="width: 200px;"><strong>Cookie Banner:</strong></td>
                        <td><?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>GA4 Tracking ID:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ ' . esc_html($ga4_id) . '</span>' : '<span style="color: #f56e28;">⚠ Not configured</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Consent Mode v2:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ Ready</span>' : '<span style="color: #999;">○ Waiting for GA4 ID</span>'; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>🚀 Quick Start</h3>
            <ol>
                <li>Go to <a href="<?php echo admin_url('admin.php?page=wpcc-settings'); ?>">Settings</a> to configure your GA4 tracking ID</li>
                <li>Customize the cookie banner text and appearance</li>
                <li>Test the banner on your site (it will appear for first-time visitors)</li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>🔄 Update Cache Management</h3>
            <p>Use this button to clear the WordPress update cache and force a check for new plugin versions from GitHub.</p>
            <form method="post" style="margin-top: 15px;">
                <?php wp_nonce_field('wpcc_refresh_cache', 'wpcc_refresh_nonce'); ?>
                <button type="submit" name="wpcc_refresh_cache" class="button button-secondary">
                    🔄 Refresh Update Cache
                </button>
                <p class="description" style="margin-top: 10px;">Click this button after pushing a new release to GitHub to check for updates immediately.</p>
            </form>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 What's in v<?php echo WPCC_VERSION; ?></h3>
            <ul>
                <li><strong>GDPR-compliant cookie consent management</strong></li>
                <li><strong>Google Analytics 4 (GA4) integration with Consent Mode v2</strong></li>
                <li><strong>Equal prominence Accept/Reject buttons</strong> - no dark patterns</li>
                <li><strong>Auto-updates via GitHub</strong> - always get the latest version</li>
                <li><strong>Zero external dependencies</strong> - works on any WordPress site</li>
            </ul>
        </div>
    </div>
    <?php
}

// Settings page
function wpcc_settings_page() {
    if (isset($_POST['wpcc_settings_submit'])) {
        check_admin_referer('wpcc_settings_save', 'wpcc_settings_nonce');

        // Sanitize and save all settings
        update_option('wpcc_enabled', isset($_POST['wpcc_enabled']) ? 1 : 0);
        update_option('wpcc_ga4_id', sanitize_text_field($_POST['wpcc_ga4_id']));
        update_option('wpcc_banner_title', sanitize_text_field($_POST['wpcc_banner_title']));
        update_option('wpcc_banner_body', wp_kses_post($_POST['wpcc_banner_body']));
        update_option('wpcc_accept_label', sanitize_text_field($_POST['wpcc_accept_label']));
        update_option('wpcc_reject_label', sanitize_text_field($_POST['wpcc_reject_label']));
        update_option('wpcc_consent_expiry_days', absint($_POST['wpcc_consent_expiry_days']));

        // Color settings
        update_option('wpcc_banner_bg_color', sanitize_hex_color($_POST['wpcc_banner_bg_color']));
        update_option('wpcc_banner_text_color', sanitize_hex_color($_POST['wpcc_banner_text_color']));
        update_option('wpcc_accept_bg_color', sanitize_hex_color($_POST['wpcc_accept_bg_color']));
        update_option('wpcc_accept_text_color', sanitize_hex_color($_POST['wpcc_accept_text_color']));
        update_option('wpcc_reject_border_color', sanitize_hex_color($_POST['wpcc_reject_border_color']));

        echo '<div class="notice notice-success is-dismissible"><p><strong>Settings saved successfully!</strong></p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Cookie Consent Settings</h1>
        <p>Configure your GDPR-compliant cookie consent banner and Google Analytics integration.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpcc_settings_save', 'wpcc_settings_nonce'); ?>

            <h2>General Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_enabled">Enable Cookie Banner</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpcc_enabled" id="wpcc_enabled" value="1" <?php checked(get_option('wpcc_enabled', true)); ?>>
                            Show cookie consent banner on the site
                        </label>
                        <p class="description">Master on/off switch for the entire cookie consent system.</p>
                    </td>
                </tr>
            </table>

            <h2>Google Analytics Configuration</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_ga4_id">GA4 Measurement ID</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_ga4_id" id="wpcc_ga4_id" value="<?php echo esc_attr(get_option('wpcc_ga4_id', '')); ?>" class="regular-text" placeholder="G-XXXXXXXXXX">
                        <p class="description">Enter your Google Analytics 4 Measurement ID (format: G-XXXXXXXXXX). Leave empty to disable GA4 tracking.</p>
                    </td>
                </tr>
            </table>

            <h2>Banner Content</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_title">Banner Title</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_banner_title" id="wpcc_banner_title" value="<?php echo esc_attr(get_option('wpcc_banner_title', 'We use cookies')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_body">Banner Message</label>
                    </th>
                    <td>
                        <textarea name="wpcc_banner_body" id="wpcc_banner_body" rows="4" class="large-text"><?php echo esc_textarea(get_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.')); ?></textarea>
                        <p class="description">The main message displayed in the cookie banner. HTML allowed (links, bold, etc.).</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_label">Accept Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_accept_label" id="wpcc_accept_label" value="<?php echo esc_attr(get_option('wpcc_accept_label', 'Accept')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_reject_label">Reject Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_reject_label" id="wpcc_reject_label" value="<?php echo esc_attr(get_option('wpcc_reject_label', 'Reject')); ?>" class="regular-text">
                    </td>
                </tr>
            </table>

            <h2>Appearance & Colors</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_bg_color">Banner Background</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_banner_bg_color" id="wpcc_banner_bg_color" value="<?php echo esc_attr(get_option('wpcc_banner_bg_color', '#ffffff')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_banner_bg_color', '#ffffff')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Background color of the cookie banner.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_text_color">Banner Text</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_banner_text_color" id="wpcc_banner_text_color" value="<?php echo esc_attr(get_option('wpcc_banner_text_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_banner_text_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Text color in the banner.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_bg_color">Accept Button Background</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_accept_bg_color" id="wpcc_accept_bg_color" value="<?php echo esc_attr(get_option('wpcc_accept_bg_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_accept_bg_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Background color of the Accept button.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_text_color">Accept Button Text</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_accept_text_color" id="wpcc_accept_text_color" value="<?php echo esc_attr(get_option('wpcc_accept_text_color', '#ffffff')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_accept_text_color', '#ffffff')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Text color of the Accept button.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wpcc_reject_border_color">Reject Button Border</label>
                    </th>
                    <td>
                        <input type="color" name="wpcc_reject_border_color" id="wpcc_reject_border_color" value="<?php echo esc_attr(get_option('wpcc_reject_border_color', '#111111')); ?>" class="wpcc-color-picker">
                        <input type="text" value="<?php echo esc_attr(get_option('wpcc_reject_border_color', '#111111')); ?>" class="regular-text" readonly style="margin-left: 10px;">
                        <p class="description">Border and text color of the Reject button.</p>
                    </td>
                </tr>
            </table>

            <h2>Behavior Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_consent_expiry_days">Consent Expiry (Days)</label>
                    </th>
                    <td>
                        <input type="number" name="wpcc_consent_expiry_days" id="wpcc_consent_expiry_days" value="<?php echo esc_attr(get_option('wpcc_consent_expiry_days', 180)); ?>" min="1" max="365" class="small-text">
                        <p class="description">Number of days before asking for consent again (1-365 days).</p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpcc_settings_submit" class="button button-primary" value="Save Settings">
            </p>

            <script>
            // Update text inputs when color pickers change
            document.querySelectorAll('.wpcc-color-picker').forEach(function(picker) {
                picker.addEventListener('input', function() {
                    this.nextElementSibling.value = this.value;
                });
            });
            </script>
        </form>
    </div>
    <?php
}

