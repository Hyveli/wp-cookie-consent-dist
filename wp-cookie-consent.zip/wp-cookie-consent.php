<?php
/**
 * Plugin Name: WP Cookie Consent
 * Plugin URI: https://github.com/hyveli/wp-cookie-consent
 * Description: GDPR-compliant cookie consent management with Google Analytics 4 (GA4) support and Consent Mode v2 integration.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Kara Concepcion
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-cookie-consent
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPCC_VERSION', '1.0.0');
define('WPCC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPCC_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-cookie-consent-dist/main/release.json',
            __FILE__,
            'wp-cookie-consent'
        );

        // Force update check if URL parameter is present
        if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
            delete_site_transient('update_plugins');
            $updateChecker->checkForUpdates();
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>✅ Update check cache cleared! WordPress will check for updates now.</p></div>';
            });
        }
    }
}

// Activation hook
register_activation_hook(__FILE__, 'wpcc_activate');
function wpcc_activate() {
    // Set default options on activation
    add_option('wpcc_enabled', true);
    add_option('wpcc_ga4_id', '');
    add_option('wpcc_banner_title', 'We use cookies');
    add_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.');
    add_option('wpcc_accept_label', 'Accept');
    add_option('wpcc_reject_label', 'Reject');
    add_option('wpcc_consent_expiry_days', 180);
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpcc_deactivate');
function wpcc_deactivate() {
    flush_rewrite_rules();
}

// ============================================
// COOKIE CONSENT FEATURES
// ============================================

// Placeholder for cookie consent functionality
// Features will be implemented according to CLAUDE.md specifications

// ============================================
// ADMIN INTERFACE
// ============================================

// Add admin menu
add_action('admin_menu', 'wpcc_add_admin_menu');
function wpcc_add_admin_menu() {
    add_menu_page(
        'Cookie Consent',
        'Cookie Consent',
        'manage_options',
        'wp-cookie-consent',
        'wpcc_admin_page',
        'dashicons-privacy',
        30
    );

    add_submenu_page(
        'wp-cookie-consent',
        'Settings',
        'Settings',
        'manage_options',
        'wpcc-settings',
        'wpcc_settings_page'
    );
}

// Register settings
add_action('admin_init', 'wpcc_register_settings');
function wpcc_register_settings() {
    register_setting('wpcc_settings_group', 'wpcc_enabled');
    register_setting('wpcc_settings_group', 'wpcc_ga4_id');
    register_setting('wpcc_settings_group', 'wpcc_banner_title');
    register_setting('wpcc_settings_group', 'wpcc_banner_body');
    register_setting('wpcc_settings_group', 'wpcc_accept_label');
    register_setting('wpcc_settings_group', 'wpcc_reject_label');
    register_setting('wpcc_settings_group', 'wpcc_consent_expiry_days');
}

// Dashboard page
function wpcc_admin_page() {
    $is_enabled = get_option('wpcc_enabled', true);
    $ga4_id = get_option('wpcc_ga4_id', '');
    $has_ga4 = !empty($ga4_id);

    // Handle update cache refresh
    $cache_refreshed = false;
    if (isset($_POST['wpcc_refresh_cache']) && check_admin_referer('wpcc_refresh_cache', 'wpcc_refresh_nonce')) {
        delete_site_transient('update_plugins');
        $cache_refreshed = true;
    }
    ?>
    <div class="wrap">
        <h1>🍪 WP Cookie Consent</h1>
        <p><strong>Version:</strong> <?php echo WPCC_VERSION; ?> | <strong>Status:</strong> <?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></p>

        <?php if ($cache_refreshed): ?>
            <div class="notice notice-success is-dismissible">
                <p><strong>Update cache cleared!</strong> WordPress will check for plugin updates now.</p>
            </div>
        <?php endif; ?>

        <div class="card" style="max-width: 800px;">
            <h2>Plugin Status</h2>
            <table class="widefat" style="margin-top: 10px;">
                <tbody>
                    <tr>
                        <td style="width: 200px;"><strong>Cookie Banner:</strong></td>
                        <td><?php echo $is_enabled ? '<span style="color: #46b450;">✓ Enabled</span>' : '<span style="color: #dc3232;">○ Disabled</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>GA4 Tracking ID:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ ' . esc_html($ga4_id) . '</span>' : '<span style="color: #f56e28;">⚠ Not configured</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Consent Mode v2:</strong></td>
                        <td><?php echo $has_ga4 ? '<span style="color: #46b450;">✓ Ready</span>' : '<span style="color: #999;">○ Waiting for GA4 ID</span>'; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>🚀 Quick Start</h3>
            <ol>
                <li>Go to <a href="<?php echo admin_url('admin.php?page=wpcc-settings'); ?>">Settings</a> to configure your GA4 tracking ID</li>
                <li>Customize the cookie banner text and appearance</li>
                <li>Test the banner on your site (it will appear for first-time visitors)</li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>🔄 Update Cache Management</h3>
            <p>Use this button to clear the WordPress update cache and force a check for new plugin versions from GitHub.</p>
            <form method="post" style="margin-top: 15px;">
                <?php wp_nonce_field('wpcc_refresh_cache', 'wpcc_refresh_nonce'); ?>
                <button type="submit" name="wpcc_refresh_cache" class="button button-secondary">
                    🔄 Refresh Update Cache
                </button>
                <p class="description" style="margin-top: 10px;">Click this button after pushing a new release to GitHub to check for updates immediately.</p>
            </form>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 What's in v<?php echo WPCC_VERSION; ?></h3>
            <ul>
                <li><strong>GDPR-compliant cookie consent management</strong></li>
                <li><strong>Google Analytics 4 (GA4) integration with Consent Mode v2</strong></li>
                <li><strong>Equal prominence Accept/Reject buttons</strong> - no dark patterns</li>
                <li><strong>Auto-updates via GitHub</strong> - always get the latest version</li>
                <li><strong>Zero external dependencies</strong> - works on any WordPress site</li>
            </ul>
        </div>
    </div>
    <?php
}

// Settings page
function wpcc_settings_page() {
    if (isset($_POST['wpcc_settings_submit'])) {
        check_admin_referer('wpcc_settings_save', 'wpcc_settings_nonce');

        // Sanitize and save all settings
        update_option('wpcc_enabled', isset($_POST['wpcc_enabled']) ? 1 : 0);
        update_option('wpcc_ga4_id', sanitize_text_field($_POST['wpcc_ga4_id']));
        update_option('wpcc_banner_title', sanitize_text_field($_POST['wpcc_banner_title']));
        update_option('wpcc_banner_body', wp_kses_post($_POST['wpcc_banner_body']));
        update_option('wpcc_accept_label', sanitize_text_field($_POST['wpcc_accept_label']));
        update_option('wpcc_reject_label', sanitize_text_field($_POST['wpcc_reject_label']));
        update_option('wpcc_consent_expiry_days', absint($_POST['wpcc_consent_expiry_days']));

        echo '<div class="notice notice-success is-dismissible"><p><strong>Settings saved successfully!</strong></p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Cookie Consent Settings</h1>
        <p>Configure your GDPR-compliant cookie consent banner and Google Analytics integration.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpcc_settings_save', 'wpcc_settings_nonce'); ?>

            <h2>General Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_enabled">Enable Cookie Banner</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpcc_enabled" id="wpcc_enabled" value="1" <?php checked(get_option('wpcc_enabled', true)); ?>>
                            Show cookie consent banner on the site
                        </label>
                        <p class="description">Master on/off switch for the entire cookie consent system.</p>
                    </td>
                </tr>
            </table>

            <h2>Google Analytics Configuration</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_ga4_id">GA4 Measurement ID</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_ga4_id" id="wpcc_ga4_id" value="<?php echo esc_attr(get_option('wpcc_ga4_id', '')); ?>" class="regular-text" placeholder="G-XXXXXXXXXX">
                        <p class="description">Enter your Google Analytics 4 Measurement ID (format: G-XXXXXXXXXX). Leave empty to disable GA4 tracking.</p>
                    </td>
                </tr>
            </table>

            <h2>Banner Content</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_title">Banner Title</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_banner_title" id="wpcc_banner_title" value="<?php echo esc_attr(get_option('wpcc_banner_title', 'We use cookies')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_banner_body">Banner Message</label>
                    </th>
                    <td>
                        <textarea name="wpcc_banner_body" id="wpcc_banner_body" rows="4" class="large-text"><?php echo esc_textarea(get_option('wpcc_banner_body', 'We use Google Analytics cookies to understand how visitors use our site. These cookies are only set after you give consent.')); ?></textarea>
                        <p class="description">The main message displayed in the cookie banner. HTML allowed (links, bold, etc.).</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_accept_label">Accept Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_accept_label" id="wpcc_accept_label" value="<?php echo esc_attr(get_option('wpcc_accept_label', 'Accept')); ?>" class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpcc_reject_label">Reject Button Text</label>
                    </th>
                    <td>
                        <input type="text" name="wpcc_reject_label" id="wpcc_reject_label" value="<?php echo esc_attr(get_option('wpcc_reject_label', 'Reject')); ?>" class="regular-text">
                    </td>
                </tr>
            </table>

            <h2>Behavior Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpcc_consent_expiry_days">Consent Expiry (Days)</label>
                    </th>
                    <td>
                        <input type="number" name="wpcc_consent_expiry_days" id="wpcc_consent_expiry_days" value="<?php echo esc_attr(get_option('wpcc_consent_expiry_days', 180)); ?>" min="1" max="365" class="small-text">
                        <p class="description">Number of days before asking for consent again (1-365 days).</p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpcc_settings_submit" class="button button-primary" value="Save Settings">
            </p>
        </form>
    </div>
    <?php
}

